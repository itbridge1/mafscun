<div class="row">
    <div class="col align-self-center">
        <?php echo $data['rows']->links(); ?>

    </div>
</div>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/layout/pagination.blade.php ENDPATH**/ ?>