<div class="card-body">
    <h5 class="mb-3">Municipality-wise Statistics</h5>
    <div class="row">
        <?php if(isset($data['districts']) && $data['districts']->count() > 0): ?>
            <?php $__currentLoopData = $data['districts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="card card-gray-dark <?php echo e($key==0? '':'collapsed-card'); ?>">
                        <div class="card-header">
                            <h3 class="card-title">
                                <?php echo e($district->name); ?>

                            </h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                               <table class="table table-bordered">
                                   <thead>
                                   <tr>
                                       <th></th>
                                       <th>Municipality</th>
                                       <th>Total</th>
                                       <th>Associated</th>
                                   </tr>
                                   </thead>
                                   <?php if(isset($district->municipalities) && $district->municipalities->count() > 0): ?>
                                   <tbody>
                                   <?php $__currentLoopData = $district->municipalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myKey => $municipality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                           <td> <?php echo e(++$myKey); ?>

                                               <input type="hidden" name="detail[<?php echo e($municipality->id); ?>][district_id]" value="<?php echo e($district->id); ?>">
                                               <input type="hidden" name="detail[<?php echo e($municipality->id); ?>][municipality_id]" value="<?php echo e($municipality->id); ?>">
                                           </td>
                                           <td> <?php echo e($municipality->name); ?> </td>
                                           <td>
                                               <?php echo Form::number('detail['.$municipality->id.'][total]',\App\Facades\ViewHelper::getValueFromStat($district->id,$municipality->id,'total')??0,[
                                                    'class' => 'form-control',

                                                ]); ?>

                                           </td>
                                           <td>
                                               <?php echo Form::number('detail['.$municipality->id.'][associated]',\App\Facades\ViewHelper::getValueFromStat($district->id,$municipality->id,'associated')??0,[
                                                    'class' => 'form-control',

                                                ]); ?>

                                           </td>
                                       </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </tbody>
                                   <?php endif; ?>
                               </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
</div>
<!-- /.card-body -->
<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
</div>

<?php $__env->startSection('formJs'); ?>
    <script src="<?php echo e(asset('backend/assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js')); ?>"></script>
    <script>
        $(function (){
            $("input[data-bootstrap-switch]").each(function(){
                $(this).bootstrapSwitch('state', $(this).prop('checked'));
            })
        })
        function showPreview(event){
            if(event.target.files.length > 0){
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("file-ip-1-preview");
                var photo = document.getElementById("photo");
                preview.src = src;
                photo.value=src;
                preview.style.display = "block";

            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/statistic/common/form.blade.php ENDPATH**/ ?>