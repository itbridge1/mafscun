<div class="global-page-hero">
    <div class="container-xl">
        <?php echo $__env->make('website.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h1 class="page-title"><?php echo $__env->yieldContent('title', 'Page'); ?></h1>
    </div>
</div>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/common/page-heading.blade.php ENDPATH**/ ?>