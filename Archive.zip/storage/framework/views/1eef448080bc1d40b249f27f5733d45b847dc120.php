<?php $__env->startSection('title', $_aboutUs['title'] ?? "About"); ?>

<?php $__env->startSection('meta'); ?>
    <?php echo $__env->make('website.common.meta', [
    '_title' => $_aboutUs->title,
    '_keywords' => $_site_setting->keywords,
    '_detail' => strip_tags($_aboutUs->description),
    '_folder' => 'aboutUs',
    '_photo' => $_aboutUs->photo,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    /* Premium Detail Page Styling */


    .detail-container {
        padding: 50px 15px !important;
        background-color: #fafdfb;
    }

    .detail-card {
        background: #ffffff !important;
        border: 1px solid var(--brand-border, #ddf3e8) !important;
        border-radius: 16px !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04) !important;
        padding: 40px !important;
    }

    .detail-featured-image-wrapper {
        float: right;
        margin: 0 0 20px 25px;
        width: 38%;
        max-width: 38%;
        display: inline-block;
    }

    .detail-featured-image-wrapper img {
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.06);
        border: 1px solid var(--brand-border, #ddf3e8);
        display: block;
    }

    .detail-card .desc img {
        max-width: 100% !important;
        height: auto !important;
        border-radius: 8px;
        margin: 15px 0;
        display: block;
    }

    @media (max-width: 768px) {
        .detail-card {
            padding: 25px 18px !important;
        }

        .detail-featured-image-wrapper {
            float: none !important;
            margin: 0 0 20px 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            display: block !important;
        }

        .detail-card .desc {
            font-size: 0.98rem !important;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Detail Page Hero Header -->
    <?php echo $__env->make('website.common.page-heading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Detail Section -->
    <div class="container-xl detail-container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-md-12">
                <div class="detail-card">
                    <h2 class="font-weight-bold mb-4" style="color: #1e293b; font-size: 1.8rem; line-height: 1.3;">
                        <?php echo e($_aboutUs->title); ?>

                    </h2>
                    <div class="detail-content-wrapper clearfix" style="border-left: 5px solid var(--brand-green, #01a755); padding-left: 20px;">
                        <?php if($_aboutUs->photo): ?>
                            <div class="detail-featured-image-wrapper">
                                <img src="<?php echo e(\App\Facades\ViewHelper::getImagePath('aboutUs', $_aboutUs->photo)); ?>" 
                                     alt="<?php echo e($_aboutUs->title); ?>" />
                            </div>
                        <?php endif; ?>
                        <div class="desc">
                            <?php echo $_aboutUs->description; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('website.home.affiliation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/about/detail.blade.php ENDPATH**/ ?>