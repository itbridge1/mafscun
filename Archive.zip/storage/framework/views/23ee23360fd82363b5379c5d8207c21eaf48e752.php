<meta name="robots" content="all">
<meta name="language" content="en_US">
<meta name="title" content="<?php echo e($_title ?? $_site_setting->title); ?>">
<meta name="author"   content="<?php echo e($_title ?? $_site_setting->title); ?>" />
<meta name="description" content="<?php echo e(strip_tags($_detail) ?? ""); ?>">
<?php if(isset($_keywords)): ?>
    <meta name="keyword" content="<?php echo e($_keywords ?? ""); ?>">
<?php endif; ?>
<meta property="og:title" content="<?php echo e($_title ?? $_site_setting->title); ?>">
<meta property="og:type" content="article" />
<meta property="og:description" content="<?php echo e(strip_tags($_detail) ?? ""); ?>"/>
<meta itemprop="name"            content="<?php echo e($_title ?? $_site_setting->title); ?>" />
<meta itemprop="description"     content="<?php echo e(strip_tags($_detail) ?? ""); ?>" />
<meta itemprop="image"           content="<?php echo e(\App\Facades\ViewHelper::getImagePath($_folder, $_photo)); ?>" />
<meta property="og:description" content="<?php echo e(strip_tags($_detail) ?? ""); ?>"/>
<meta property="og:type" content="website"/>
<meta property="og:title" content="<?php echo e($_title ?? $_site_setting->title); ?>"/>
<meta property="og:url" content="<?php echo e(\Illuminate\Support\Facades\URL::current()); ?>"/>
<meta property="site_name" content="<?php echo e($_title ?? $_site_setting->title); ?>"/>
<meta property="description" content="<?php echo e(strip_tags($_detail) ?? ""); ?>"/>
<meta property="image" content="<?php echo e(\App\Facades\ViewHelper::getImagePath($_folder, $_photo)); ?>"/>
<meta property="og:type" content="website" />
<meta property="og:image" content="<?php echo e(\App\Facades\ViewHelper::getImagePath($_folder, $_photo)); ?>"/>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/common/meta.blade.php ENDPATH**/ ?>