<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="sub-title">AboutUs Setting</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>AboutUs HomePage 1</label> <span class="red">*</span>
                        <?php echo Form::select('about_1', $data['aboutUs'],null,[
                              'class'=> $errors->has('about_1')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT ABOUT US PAGE--",
                        ]); ?>

                        <?php $__errorArgs = ['about_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Commitment From CEO</label>
                        <?php echo Form::select('about_2', $data['aboutUs'],null,[
                              'class'=> $errors->has('about_2')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT ABOUT US PAGE--",
                        ]); ?>

                        <?php $__errorArgs = ['about_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Chairman Voice</label> <span class="red">*</span>
                        <?php echo Form::select('about_3', $data['aboutUs'],null,[
                              'class'=> $errors->has('about_3')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT ABOUT US PAGE--",
                        ]); ?>

                        <?php $__errorArgs = ['about_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>AboutUs HomePage 4</label> <span class="red">*</span>
                        <?php echo Form::select('about_4', $data['aboutUs'],null,[
                              'class'=> $errors->has('about_4')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT ABOUT US PAGE--",
                        ]); ?>

                        <?php $__errorArgs = ['about_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="sub-title">Footer Setting</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>First Footer</label> <span class="red">*</span>
                        <?php echo Form::select('footer_1', $data['menus'],null,[
                              'class'=> $errors->has('footer_1')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT FIRST FOOTER MENU--",
                        ]); ?>

                        <?php $__errorArgs = ['footer_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Second Footer</label> <span class="red">*</span>
                        <?php echo Form::select('footer_2', $data['menus'],null,[
                              'class'=> $errors->has('footer_2')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT SECOND FOOTER MENU--",
                        ]); ?>

                        <?php $__errorArgs = ['footer_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Third Footer</label> <span class="red">*</span>
                        <?php echo Form::select('footer_3', $data['menus'],null,[
                              'class'=> $errors->has('footer_3')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT THIRD FOOTER MENU--",
                        ]); ?>

                        <?php $__errorArgs = ['footer_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Fourth Footer</label>
                        <?php echo Form::select('footer_4', $data['menus'],null,[
                              'class'=> $errors->has('footer_4')?'form-control is-invalid':'form-control',
                              'placeholder'=>"--SELECT FOURTH FOOTER MENU--",
                        ]); ?>

                        <?php $__errorArgs = ['footer_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Statistics Text</label>
                        <?php echo Form::text('statistics_text',null,[
                              'class'=> $errors->has('statistics_text')?'form-control is-invalid':'form-control',
                              'placeholder'=>"Eg. Type Here",
                        ]); ?>

                        <?php $__errorArgs = ['statistics_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Statistics Title for chart</label>
                        <?php echo Form::text('copyright_text',null,[
                              'class'=> $errors->has('copyright_text')?'form-control is-invalid':'form-control',
                              'placeholder'=>"Eg. Type Here",
                        ]); ?>

                        <?php $__errorArgs = ['copyright_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Footer Text</label>
                        <?php echo Form::textarea('footer_text',null,[
                              'class'=> $errors->has('footer_text')?'form-control summernote is-invalid':'form-control summernote',
                              'placeholder'=>"Eg. Type Here",
                        ]); ?>

                        <?php $__errorArgs = ['footer_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/setting.blade.php ENDPATH**/ ?>