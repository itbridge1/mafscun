<aside class="news-events-dock" aria-label="Latest updates, notices and events">
    <button class="news-events-dock__tab" type="button" aria-expanded="false" aria-controls="news-events-dock-panel">
        <i class="fas fa-bullhorn" aria-hidden="true"></i><span>Notices &amp; Events</span>
    </button>
    <div class="news-events-dock__panel" id="news-events-dock-panel">
        <div class="news-events-dock__heading">
            <div><small>STAY INFORMED</small><h2>Notices &amp; Events</h2></div>
            <button class="news-events-dock__close" type="button" aria-label="Close news and events">&times;</button>
        </div>
        <section class="news-events-dock__section" aria-labelledby="dock-notices-heading">
            <div class="news-events-dock__section-title"><h3 id="dock-notices-heading">Recent notices</h3><a href="<?php echo e(route('notices')); ?>">See all</a></div>
            <?php $__empty_1 = true; $__currentLoopData = $_dock_notices ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="news-events-dock__item" href="<?php echo e(route('notices.detail', $item->slug)); ?>">
                    <span class="news-events-dock__date"><?php echo e(optional($item->created_at)->format('d M')); ?></span>
                    <span><?php echo e($item->title); ?></span><i class="fas fa-arrow-right" aria-hidden="true"></i>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="news-events-dock__empty">No recent notices.</p>
            <?php endif; ?>
        </section>
        <section class="news-events-dock__section" aria-labelledby="dock-events-heading">
            <div class="news-events-dock__section-title"><h3 id="dock-events-heading">Recent events</h3><a href="<?php echo e(route('events.index')); ?>">See all</a></div>
            <?php $__empty_1 = true; $__currentLoopData = $_dock_events ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="news-events-dock__item" href="<?php echo e(route('events.show', $item->slug)); ?>">
                    <span class="news-events-dock__date"><?php echo e(optional($item->start_date)->format('d M')); ?></span>
                    <span><?php echo e($item->title); ?></span><i class="fas fa-arrow-right" aria-hidden="true"></i>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="news-events-dock__empty">No recent events.</p>
            <?php endif; ?>
        </section>
        <section class="news-events-dock__section" aria-labelledby="dock-news-heading">
            <div class="news-events-dock__section-title"><h3 id="dock-news-heading">Recent news</h3><a href="<?php echo e(route('news')); ?>">See all</a></div>
            <?php $__empty_1 = true; $__currentLoopData = $_dock_news ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="news-events-dock__item" href="<?php echo e(route('news.detail', $item->slug)); ?>">
                    <span class="news-events-dock__date"><?php echo e(optional($item->created_at)->format('d M')); ?></span>
                    <span><?php echo e($item->title); ?></span><i class="fas fa-arrow-right" aria-hidden="true"></i>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="news-events-dock__empty">No recent news.</p>
            <?php endif; ?>
        </section>
    </div>
</aside>
<script>
    (() => {
        const dock = document.querySelector('.news-events-dock');
        if (!dock) return;
        const toggle = dock.querySelector('.news-events-dock__tab');
        const close = dock.querySelector('.news-events-dock__close');
        const setOpen = (open) => {
            dock.classList.toggle('is-open', open);
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        };
        toggle.addEventListener('click', () => setOpen(!dock.classList.contains('is-open')));
        close.addEventListener('click', () => setOpen(false));
        document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setOpen(false); });
    })();
</script>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/common/news-events-dock.blade.php ENDPATH**/ ?>