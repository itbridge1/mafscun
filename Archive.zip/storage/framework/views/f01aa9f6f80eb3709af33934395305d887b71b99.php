<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="sub-title">Site Information </h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="title">Title </label> <span class="red">*</span>
                        <?php echo Form::text('title', null,[
                              'class'=> $errors->has('title')?'form-control is-invalid':'form-control',
                              'placeholder'=>"Type Site Name here..",
                              ]); ?>

                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                <strong> <?php echo e($message); ?> </strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="title">Sub Title </label> <span class="red">*</span>
                        <?php echo Form::text('sub_title', null,[
                              'class'=> $errors->has('sub_title')?'form-control is-invalid':'form-control',
                              'placeholder'=>"Type Site Sub Title here..",
                              ]); ?>

                        <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                <strong> <?php echo e($message); ?> </strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="title">Company Alias </label> <span class="red">*</span>
                        <?php echo Form::text('company_alias', null,[
                              'class'=> $errors->has('company_alias')?'form-control is-invalid':'form-control',
                              'placeholder'=>"Type Site Name Shortcut..",
                              ]); ?>

                        <?php $__errorArgs = ['company_alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Email </label> <span class="red">*</span>
                        
                        <?php echo Form::text('email', null,[
                              'class'=> $errors->has('email')?'form-control is-invalid':'form-control',
                              'placeholder'=>"Type Site Email here..",
                              ]); ?>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                <strong> <?php echo e($message); ?> </strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="phone">Phone No</label> <span class="red">*</span>
                        <?php echo Form::text('phone', null,[
                             'class'=> $errors->has('phone')?'form-control is-invalid':'form-control',
                             'placeholder'=>'eg. 9814525625',
                             ]); ?>

                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                 <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>PAN No</label> <span class="red">*</span>
                        <?php echo Form::text('pan_no', null,[
                             'class'=> $errors->has('pan_no')?'form-control is-invalid':'form-control',
                             'placeholder'=>'eg. 15825625',
                             ]); ?>

                        <?php $__errorArgs = ['pan_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                 <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Reg No</label> <span class="red">*</span>
                        <?php echo Form::text('reg_no', null,[
                             'class'=> $errors->has('reg_no')?'form-control is-invalid':'form-control',
                             'placeholder'=>'eg. Darta No.',
                             ]); ?>

                        <?php $__errorArgs = ['reg_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Location</label> <span class="red">*</span>
                        <?php echo Form::text('location', null,[
                             'class'=> $errors->has('location')?'form-control is-invalid':'form-control',
                             'placeholder'=>'eg. Banepa -3, Kavre',
                             ]); ?>

                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <?php if(isset($errors)): ?>
                        <?php echo e($errors); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12">
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="sub-title">Public Site Colors</h5>
            <p class="text-muted">These colors update the public website, including page headings and breadcrumbs.</p>
            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="primary_color">Primary color</label>
                    <input id="primary_color" name="primary_color" type="color" class="form-control" style="height:48px;padding:5px" value="<?php echo e(old('primary_color', $data['row']->primary_color ?? '#08784b')); ?>">
                    <?php $__errorArgs = ['primary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-6 form-group">
                    <label for="secondary_color">Secondary color</label>
                    <input id="secondary_color" name="secondary_color" type="color" class="form-control" style="height:48px;padding:5px" value="<?php echo e(old('secondary_color', $data['row']->secondary_color ?? '#00acf1')); ?>">
                    <?php $__errorArgs = ['secondary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="invalid-feedback d-block"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/home.blade.php ENDPATH**/ ?>