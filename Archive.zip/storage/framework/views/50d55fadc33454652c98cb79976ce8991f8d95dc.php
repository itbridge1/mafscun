<aside class="main-sidebar sidebar-dark-primary elevation-4 sidebar-light-purple">

    <a href="<?php echo e(url('/home')); ?>" class="brand-link navbar-gray">
        <img src="<?php echo e(\App\Facades\ViewHelper::getImagePath('siteSetting', $_site_setting->company_logo) ??asset('backend/assets/dist/img/AdminLTELogo.png')); ?>" alt="<?php echo e($_site_setting->company_alias ??  env('APP_NAME')); ?> Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text white font-weight-light">
            <?php echo e($_site_setting->company_alias ??  env('APP_NAME')); ?>

        </span>
    </a>

    <div class="sidebar">
         <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                        <div class="image">
                            <img src="<?php echo e(\App\Facades\ViewHelper::getImagePath('user',auth()->user()->photo??'no-image.png')); ?>" class="img-circle elevation-2" alt="User Image">
                        </div>
                        <div class="info">
                            <a href="<?php echo e(route('admin.user.profile')); ?>" class="d-block"><?php echo e(auth()->user()->name?? 'User'); ?></a>
                        </div>
                    </div>

         <nav class="mt-2">
                        <ul class="nav nav-pills nav-sidebar nav-flat nav-child-indent flex-column" data-widget="treeview" role="menu" data-accordion="false">

                            <li class="nav-item">
                                <a href="<?php echo e($dashboard_url??'#'); ?>" class="nav-link <?php echo e(request()->is('home') || request()->is('admin/dashboard') ? 'active':''); ?>">
                                    <i class="nav-icon fas fa-tachometer-alt"></i>
                                    <p>
                                        Dashboard
                                    </p>
                                </a>
                            </li>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['role-create','role-index'])): ?>
                                <li class="nav-item <?php echo e(request()->is('admin/role*')?'menu-open':''); ?>">
                                    <a href="<?php echo e(route('admin.role.index')); ?>" class="nav-link <?php echo e(request()->is('admin/role*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-th marine"></i>
                                        <p>
                                            Role
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['permission-create','permission-index'])): ?>
                                <li class="nav-item <?php echo e(request()->is('admin/permission*')?'menu-open':''); ?>">
                                    <a href="<?php echo e(route('admin.permission.index')); ?>" class="nav-link <?php echo e(request()->is('admin/permission*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-lock"></i>
                                        <p>
                                            Permission
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['user-create','user-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.user.index')); ?>" class="nav-link <?php echo e(request()->is('admin/user*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-user-cog"></i>
                                        <p>
                                            User
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php
                                $pendingBookingsCount = \App\Models\EventBooking::where('status', \App\Models\EventBooking::STATUS_PENDING)->count();
                            ?>
                            <li class="nav-item <?php echo e(request()->is('admin/event*') || request()->is('admin/paymentQr*') || request()->is('admin/otp-requests*') || request()->is('admin/cooperativeInformation*') ?'menu-open':''); ?>">
                                <a href="#" class="nav-link <?php echo e(request()->is('admin/event*') || request()->is('admin/paymentQr*') || request()->is('admin/otp-requests*') || request()->is('admin/cooperativeInformation*') ?'active':''); ?>">
                                    <i class="nav-icon fas marine fa-calendar-check"></i>
                                    <p>
                                        Events Management
                                        <i class="fas marine fa-angle-left right"></i>
                                        <span class="badge <?php echo e($pendingBookingsCount > 0 ? 'badge-warning' : 'badge-light text-dark'); ?> right" style="margin-right: 1.5rem;"><?php echo e($pendingBookingsCount); ?></span>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.event.index')); ?>" class="nav-link <?php echo e(request()->is('admin/event*')?'active':''); ?>">
                                            <i class="nav-icon fas marine fa-calendar-alt"></i>
                                            <p>
                                                Events
                                                <span class="badge <?php echo e($pendingBookingsCount > 0 ? 'badge-warning' : 'badge-light text-dark'); ?> right"><?php echo e($pendingBookingsCount); ?></span>
                                            </p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.paymentQr.index')); ?>" class="nav-link <?php echo e(request()->is('admin/paymentQr*')?'active':''); ?>">
                                            <i class="nav-icon fas marine fa-qrcode"></i>
                                            <p>Payment QRs</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.otp-requests.index')); ?>" class="nav-link <?php echo e(request()->is('admin/otp-requests*')?'active':''); ?>">
                                            <i class="nav-icon fas marine fa-sms"></i>
                                            <p>OTP Requests</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.cooperativeInformation.index')); ?>" class="nav-link <?php echo e(request()->is('admin/cooperativeInformation*')?'active':''); ?>">
                                            <i class="nav-icon fas marine fa-building"></i>
                                            <p>Cooperatives</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('admin/dev*')?'menu-open':''); ?>">
                                <a href="#" class="nav-link <?php echo e(request()->is('admin/dev*')?'active':''); ?>">
                                    <i class="nav-icon fas marine fa-cog"></i>
                                    <p>
                                        Development Mode
                                        <i class="fas marine fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['hrm-create','hrm-index'])): ?>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('admin.hrm.index')); ?>" class="nav-link <?php echo e(request()->is('admin/dev/hrm*')?'active':''); ?>">
                                                <i class="nav-icon fas marine fa-users"></i>
                                                <p>
                                                    HRM
                                                </p>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['serviceCategory-create','serviceCategory-index'])): ?>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('admin.serviceCategory.index')); ?>" class="nav-link <?php echo e(request()->is('admin/dev/serviceCategory*')?'active':''); ?>">
                                                <i class="nav-icon fas marine fa-server"></i>
                                                <p>
                                                    ServiceCategory
                                                </p>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['category-create','category-index'])): ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('admin.category.index')); ?>" class="nav-link <?php echo e(request()->is('admin/dev/category*')?'active':''); ?>">
                                                    <i class="nav-icon fas marine fa-list"></i>
                                                    <p>
                                                        Category
                                                    </p>
                                                </a>
                                            </li>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['resourceType-create','resourceType-index'])): ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('admin.resourceType.index')); ?>" class="nav-link <?php echo e(request()->is('admin/dev/resourceType*')?'active':''); ?>">
                                                    <i class="nav-icon fas marine fa-file-archive"></i>
                                                    <p>
                                                        ResourceType
                                                    </p>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                </ul>
                            </li>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['aboutUs-create','aboutUs-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.aboutUs.index')); ?>" class="nav-link <?php echo e(request()->is('admin/aboutUs*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-info"></i>
                                        <p>
                                            AboutUs
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['slider-create','slider-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.slider.index')); ?>" class="nav-link <?php echo e(request()->is('admin/slider*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-image"></i>
                                        <p>
                                            Slider
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['notice-create','notice-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.notice.index')); ?>" class="nav-link <?php echo e(request()->is('admin/notice*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-broadcast-tower"></i>
                                        <p>
                                            Notice
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['news-create','news-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.news.index')); ?>" class="nav-link <?php echo e(request()->is('admin/news*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-newspaper"></i>
                                        <p>
                                            News
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['resource-create','resource-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.resource.index')); ?>" class="nav-link <?php echo e(request()->is('admin/resource') || request()->is('admin/resource/*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-download"></i>
                                        <p>
                                            Resource
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['gallery-create','gallery-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.gallery.index')); ?>" class="nav-link <?php echo e(request()->is('admin/gallery*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-images"></i>
                                        <p>
                                            Gallery
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['affiliation-create','affiliation-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.affiliation.index')); ?>" class="nav-link <?php echo e(request()->is('admin/affiliation*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-lightbulb"></i>
                                        <p>
                                            Affliation
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['district-create','district-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.district.index')); ?>" class="nav-link <?php echo e(request()->is('admin/district*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-map"></i>
                                        <p>
                                            District
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['municipality-create','municipality-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.municipality.index')); ?>" class="nav-link <?php echo e(request()->is('admin/municipality*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-map-marked"></i>
                                        <p>
                                            Municipality
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['service-create','service-index'])): ?>
                            <li class="nav-item <?php echo e(\App\Facades\ViewHelper::checkServiceURL()?'menu-open':''); ?>">
                                <a href="#" class="nav-link <?php echo e(\App\Facades\ViewHelper::checkServiceURL()?'active':''); ?>">
                                    <i class="nav-icon fas marine fa-baby-carriage"></i>
                                    <p>Services
                                        <i class="fas marine fa-angle-left right"></i>
                                    </p>
                                </a>
                                <?php if(isset($_service_categories) && $_service_categories->count() > 0): ?>
                                <ul class="nav nav-treeview">
                                    <?php $__currentLoopData = $_service_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('admin.service.index',$serviceCategory->slug)); ?>" class="nav-link <?php echo e(request()->is('admin/'.$serviceCategory->slug.'/service*')?'active':''); ?>">
                                            <i class="nav-icon fas marine fa-baby"></i>
                                            <p>
                                               <?php echo e($serviceCategory->title); ?>

                                            </p>
                                        </a>
                                        <?php if(isset($serviceCategory->child) && $serviceCategory->child->count() > 0): ?>
                                            <ul class="nav nav-treeview">
                                                <?php $__currentLoopData = $serviceCategory->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="nav-item">
                                                        <a href="<?php echo e(route('admin.service.index',$serviceCat->slug)); ?>" class="nav-link <?php echo e(request()->is('admin/'.$serviceCat->slug.'/service*')?'active':''); ?>">
                                                            <i class="nav-icon fas marine fa-baby"></i>
                                                            <p>
                                                                <?php echo e($serviceCat->title); ?>

                                                            </p>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['team-create','team-index'])): ?>
                                <li class="nav-item <?php echo e(str_contains( \Illuminate\Support\Facades\URL::current(),'/team')?'menu-open':''); ?>">
                                    <a href="#" class="nav-link <?php echo e(str_contains( \Illuminate\Support\Facades\URL::current(),'/team') ?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-users"></i>
                                        <p>Teams <?php echo e(str_contains('/team', \Illuminate\Support\Facades\URL::current())==1); ?>

                                            <i class="fas marine fa-angle-left right"></i>
                                        </p>
                                    </a>
                                    <?php if(isset($_hrm) && $_hrm->count() > 0): ?>
                                        <ul class="nav nav-treeview">
                                            <?php $__currentLoopData = $_hrm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hrmCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item">
                                                    <a href="<?php echo e(route('admin.team.index',$hrmCategory->slug)); ?>" class="nav-link <?php echo e(request()->is('admin/'.$hrmCategory->slug.'/team*')?'active':''); ?>">
                                                        <i class="nav-icon fas marine fa-user-friends"></i>
                                                        <p>
                                                            <?php echo e($hrmCategory->title); ?>

                                                        </p>
                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['statistic-create','statistic-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.statistic.index')); ?>" class="nav-link <?php echo e(request()->is('admin/statistic*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-database"></i>
                                        <p>
                                            Statistics
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['siteSetting-create','siteSetting-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.siteSetting.index')); ?>" class="nav-link <?php echo e(request()->is('admin/siteSetting*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-sitemap"></i>
                                        <p>
                                            Site Setting
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['memberOrganization-create','memberOrganization-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.memberOrganization.index')); ?>" class="nav-link <?php echo e(request()->is('admin/memberOrganization*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-building"></i>
                                        <p>
                                            Member Organization
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['successStory-create','successStory-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.successStory.index')); ?>" class="nav-link <?php echo e(request()->is('admin/successStory*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-user-check"></i>
                                        <p>
                                            Success Story
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['contactForm-create','contactForm-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.contactForm.index')); ?>" class="nav-link <?php echo e(request()->is('admin/contactForm*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-phone-alt"></i>
                                        <p>
                                            ContactForm
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.agmForm.index')); ?>" class="nav-link <?php echo e(request()->is('admin/agmForm*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-users-alt"></i>
                                        <p>
                                           AgmForm
                                        </p>
                                    </a>
                                </li>
                            

                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.SuggestionForm.index')); ?>" class="nav-link <?php echo e(request()->is('admin/SuggestionForm*')?'active':''); ?>">
                                    <i class="nav-icon fas marine fa-users-alt"></i>
                                    <p>
                                       SuggestionForm
                                    </p>
                                </a>
                            </li>

                                
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['menu-create','menu-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.menu.index')); ?>" class="nav-link <?php echo e(request()->is('admin/menu*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-list-ul"></i>
                                        <p>
                                            Menu
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['faq-create','faq-index'])): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.faq.index')); ?>" class="nav-link <?php echo e(request()->is('admin/faq*')?'active':''); ?>">
                                        <i class="nav-icon fas marine fa-question"></i>
                                        <p>
                                            FAQ
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <li class="nav-item nav-header"></li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
                                   class="nav-link">
                                    <i class="nav-icon fas marine fa-backspace"></i>
                                    <p>
                                        Log Out
                                    </p>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </nav>
    </div>
</aside>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/layout/sidebar.blade.php ENDPATH**/ ?>