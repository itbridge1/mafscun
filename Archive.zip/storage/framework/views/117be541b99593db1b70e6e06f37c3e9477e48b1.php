<!doctype html>
<html lang="en" style="overflow-x: hidden;">
<?php echo $__env->make('website.common.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('website.common.mis-dock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('website.common.news-events-dock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Full-width contact strip -->
<?php echo $__env->make('website.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ==========navbar section========== -->
<?php echo $__env->make('website.common.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ==========End nabar section========== -->


<link rel="stylesheet" href="<?php echo e(asset('website/assets/public-refresh.css')); ?>?v=<?php echo e(filemtime(public_path('website/assets/public-refresh.css'))); ?>">
<style>
    :root {
        --public-green: <?php echo e(preg_match('/^#[0-9A-Fa-f]{6}$/', $_site_setting->primary_color ?? '') ? $_site_setting->primary_color : '#08784b'); ?>;
        --public-deep: color-mix(in srgb, var(--public-green) 82%, #000);
        --brand-green: var(--public-green);
        --brand-green-hover: var(--public-deep);
        --public-secondary: <?php echo e(preg_match('/^#[0-9A-Fa-f]{6}$/', $_site_setting->secondary_color ?? '') ? $_site_setting->secondary_color : '#00acf1'); ?>;
        --brand-cyan: var(--public-secondary);
    }
</style>


    <?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('website.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/common/layout.blade.php ENDPATH**/ ?>