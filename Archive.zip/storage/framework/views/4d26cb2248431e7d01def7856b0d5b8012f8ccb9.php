<?php if(isset($row->statistics) && $row->statistics->count() > 0): ?>
    <?php $__currentLoopData = $row->statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $increment => $_statistics_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <input type="hidden" name="statisticsData[<?php echo e($increment); ?>][id]" value="<?php echo e($_statistics_data->id); ?>">
                <input class="form-control" name="statisticsData[<?php echo e($increment); ?>][name]"
                    value="<?php echo e($_statistics_data->name); ?>" type="text">
            </td>
            <td>
                <input class="form-control" name="statisticsData[<?php echo e($increment); ?>][value]"
                    value="<?php echo e($_statistics_data->value); ?>" type="text">
            </td>
            <td>
                <input class="form-control" name="statisticsData[<?php echo e($increment); ?>][rank]"
                    value="<?php echo e($_statistics_data->rank); ?>" type="number">
            </td>
            <td>
                <input type="file" name="stat_photo_<?php echo e($increment); ?>" class="form-control" accept="image/*" onchange="previewImage(this, 'photo_preview_<?php echo e($increment); ?>')">
                <?php if($_statistics_data->photo): ?>
                    <img src="<?php echo e(asset('images/siteSetting/' . $_statistics_data->photo)); ?>" alt="Current Photo" style="width: 50px; height: 50px; margin-top: 5px;">
                <?php endif; ?>
                <img id="photo_preview_<?php echo e($increment); ?>" src="" alt="Photo Preview" style="width: 50px; height: 50px; margin-top: 5px; display: none;">
            </td>
            <td>
                <button id="remove" type="button" class="btn btn-danger btn-sm remove-row"><i class="fa fa-minus"></i></button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/statistics_table-row-edit.blade.php ENDPATH**/ ?>