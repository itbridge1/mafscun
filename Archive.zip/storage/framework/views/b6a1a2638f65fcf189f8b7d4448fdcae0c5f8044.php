<?php $__env->startSection('title', $_panel . ' List'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6"><h1><?php echo e($_panel); ?></h1></div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e($dashboard_url); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item active"><?php echo e($_panel); ?> List</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">List of <?php echo e($_panel); ?></h3>
                                <a href="<?php echo e(route($_base_route . '.create')); ?>" class="btn btn-primary float-right">
                                    <i class="fas fa-plus"></i> Add New <?php echo e($_panel); ?>

                                </a>
                            </div>
                            <div class="card-body">
                                <?php echo $__env->make('admin.layout.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>SN</th>
                                            <th>Photo</th>
                                            <th>Title</th>
                                            <th>Total Seats</th>
                                            <th>Avail. Seats</th>
                                            <th>Reg. Deadline</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $data['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td>
                                                <?php if($row->photo): ?>
                                                    <img src="<?php echo e(\App\Facades\ViewHelper::getImagePath('events', $row->photo)); ?>"
                                                         width="60" height="40" class="img-fluid rounded">
                                                <?php else: ?>
                                                    <span class="text-muted">—</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($row->title); ?></td>
                                            <td><?php echo e($row->total_seats); ?></td>
                                            <td><span class="text-success font-weight-bold"><?php echo e($row->availableSeats()); ?></span></td>
                                            <td>
                                                <?php if($row->registration_deadline): ?>
                                                    <span class="<?php echo e($row->isRegistrationOpen() ? 'text-success' : 'text-danger font-weight-bold'); ?>"><?php echo e($row->registration_deadline->format('Y-m-d')); ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge badge-<?php echo e($row->status ? 'success' : 'danger'); ?>">
                                                    <?php echo e($row->status ? 'Active' : 'Inactive'); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.event.show', $row->id)); ?>" class="btn btn-sm btn-info">
                                                    <i class="fa fa-eye"></i> View
                                                </a>
                                                <?php
                                                    $pendingForEvent = $row->bookings()->where('status', \App\Models\EventBooking::STATUS_PENDING)->count();
                                                ?>
                                                <a href="<?php echo e(route('admin.event.bookings', $row->id)); ?>" class="btn btn-sm btn-warning">
                                                    <i class="fa fa-calendar-check-o"></i> Bookings
                                                    <span class="badge badge-<?php echo e($pendingForEvent > 0 ? 'danger' : 'light'); ?> ml-1 text-dark" style="<?php echo e($pendingForEvent == 0 ? 'background-color: rgba(255,255,255,0.7);' : ''); ?>"><?php echo e($pendingForEvent); ?> Pending</span>
                                                </a>
                                                <a href="<?php echo e(route('admin.event.edit', $row->id)); ?>" class="btn btn-sm btn-success">
                                                    <i class="fa fa-edit"></i> Edit
                                                </a>
                                                <a href="<?php echo e(route('admin.event.certificate.settings', $row->id)); ?>" class="btn btn-sm btn-dark">
                                                    <i class="fa fa-cog"></i> Certificate
                                                </a>
                                                <a href="javascript:void(0)"
                                                   onclick="var c=confirm('Are you sure?');if(c){document.getElementById('delete-<?php echo e($row->id); ?>').submit();}"
                                                   class="btn btn-sm btn-danger">
                                                    <i class="fa fa-trash"></i> Delete
                                                </a>
                                                <form id="delete-<?php echo e($row->id); ?>" action="<?php echo e(route('admin.event.destroy', $row->id)); ?>" method="POST" style="display:none;">
                                                    <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#example1").DataTable({
                "responsive": true, "lengthChange": true, "autoWidth": false, "info": true, "paging": true,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/event/index.blade.php ENDPATH**/ ?>