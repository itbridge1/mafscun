<div class="card-body">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="name">ResourceType *</label>
                <?php echo Form::select('resource_type_id',$data['resource_types'], null,[
                      'class'=> $errors->has('resource_type_id')?'form-control is-invalid':'form-control',
                      'placeholder'=>'--SELECT RESOURCE TYPE--',
                      ]); ?>

                <?php $__errorArgs = ['resource_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block invalid-feedback">
                        <strong> <?php echo e($message); ?> </strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label for="name">Title*</label>
                <?php echo Form::text('title', null,[
                      'class'=> $errors->has('title')?'form-control is-invalid':'form-control',
                      'placeholder'=>'Eg.Introduction',
                      ]); ?>

                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="help-block invalid-feedback">
                        <strong> <?php echo e($message); ?> </strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label for="name">Sub Title</label>
                <?php echo Form::text('sub_title', null,[
                      'class'=> $errors->has('sub_title')?'form-control is-invalid':'form-control',
                      'placeholder'=>'Eg.Introduction',
                      ]); ?>

                <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block invalid-feedback">
                        <strong> <?php echo e($message); ?> </strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label for="title">Status</label><br>
                <?php echo Form::checkbox('status', null,isset($data['row'])?null:true, [
                   'class'=> $errors->has('status')?'is-invalid':'',
                   'data-bootstrap-switch',
                   'data-off-color' => 'danger',
                   'data-on-color' => 'success',
                   'data-on-text' => 'ACTIVE',
                   'data-off-text' => 'INACTIVE'
                ]); ?>

                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block invalid-feedback">
                     <strong> <?php echo e($message); ?> </strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <label>UploadType <span class="red">*</span></label>
                <?php echo Form::select('type',config('helper.fileType'), null,[
                     'class'=> $errors->has('type')?'form-control type is-invalid':'form-control type',
                     ]); ?>

                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block invalid-feedback">
                     <strong> <?php echo e($message); ?> </strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-6 link">
            <div class="form-group">
                <label>Link <span class="red">*</span></label>
                <?php echo Form::text('link', (isset($data['row']) && $data['row']->type == "link")? $data['row']->file : null,[
                     'class'=> $errors->has('link')?'form-control is-invalid':'form-control',
                     'placeholder'=>'Enter link here..',
                     ]); ?>

                <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block invalid-feedback">
                     <strong> <?php echo e($message); ?> </strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-12 file">
            <div class="card card-gray-dark">
                <div class="card-header">
                    File
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="photo_upload">Upload File</label>
                            <?php echo Form::file('main_file',[
                                'class'=> $errors->has('main_file')?'form-control btn btn-sm is-invalid':'form-control btn btn-sm',
                                'id'=>'photo',
                                'onchange'=>"showPreview(event);",

                             ]); ?>

                            <?php $__errorArgs = ['main_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="photo">Existing Image</label>
                            <div class="preview">
                                <img width="200" height="200" src="<?php echo e(ViewHelper::getImagePath(@$_folder,@$data['row']->file)); ?>"
                                     class="img-responsive"
                                     id="file-ip-1-preview">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="form-group">
                <label for="title">Description</label>
                <?php echo Form::textarea('description', null,[
                     'class'=> $errors->has('description')?'form-control summernote is-invalid':'form-control summernote',
                     'placeholder'=>'Eg. Description',
                ]); ?>

                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block invalid-feedback">
                     <strong> <?php echo e($message); ?> </strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
</div>
<!-- /.card-body -->
<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
</div>

<?php $__env->startSection('formJs'); ?>
    <script src="<?php echo e(asset('backend/assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js')); ?>"></script>

    <script>
        function showPreview(event){
            if(event.target.files.length > 0){
                var src = URL.createObjectURL(event.target.files[0]);
                var preview = document.getElementById("file-ip-1-preview");
                var photo = document.getElementById("photo");
                preview.src = src;
                photo.value=src;
                preview.style.display = "block";

            }
        }
    </script>
    <script>
        $(function () {
            checkUploadType();
            $("input[data-bootstrap-switch]").each(function(){
                $(this).bootstrapSwitch('state', $(this).prop('checked'));
            })
            $('.type').change(function (){
                checkUploadType();
            });
            function checkUploadType(){
                var type = $('.type').val();
                if(type=== "link" || type === "video"){
                    $('.link').show();
                    $('.file').hide();
                }else{
                    $('.file').show();
                    $('.link').hide();
                }
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/resource/common/form.blade.php ENDPATH**/ ?>