<?php if(isset($_affiliations) && $_affiliations->count() > 0): ?>
    <section class="affiliation-section" aria-labelledby="affiliationTitle">
        <div class="container-xl">
            <div class="affiliation-heading">
                <p class="affiliation-kicker">Our network</p>
                <h2 id="affiliationTitle">Affiliations &amp; partnerships</h2>
                <p>Working together with organizations that strengthen cooperative communities.</p>
            </div>

            <div class="affiliation-carousel-shell">
                <section class="customer-logos" aria-label="Affiliated organizations">
                    <?php $__currentLoopData = $_affiliations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="affiliation-slide">
                            <a href="<?php echo e($affiliation->link ?: '#'); ?>" <?php if($affiliation->link): ?> target="_blank" rel="noopener noreferrer" <?php endif; ?>>
                                <span class="affiliation-logo-frame">
                                    <img src="<?php echo e(\App\Facades\ViewHelper::getImagePath('affiliation', $affiliation->logo)); ?>"
                                         alt="<?php echo e($affiliation->title ?: 'Affiliation partner'); ?>"
                                         loading="lazy">
                                </span>
                                <?php if($affiliation->title): ?>
                                    <span class="affiliation-name"><?php echo e($affiliation->title); ?></span>
                                <?php endif; ?>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/home/affiliation.blade.php ENDPATH**/ ?>