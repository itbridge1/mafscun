<div class="col-md-12">
    <div class="card card-gray-dark">
        <div class="card-header">
            Statistics Detail
        </div>
        <div class="card-body">
            <div class="row">
                <div class="table-responsive">
                    <table id="statistics_form" class="table table-bordered nobottommargin">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Value</th>
                                <th>Rank</th>

                                <th>
                                    <button id="statistics_detail" type="button" class="btn btn-success btn-sm">
                                        <i class="fa fa-plus">
                                        </i>
                                    </button>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($data['row'])): ?>
                                <?php echo $__env->make('admin.siteSetting.common.statistics_table-row-edit', [
                                    'row' => $data['row'],
                                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('admin.siteSetting.common.statistics_table-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/statistics.blade.php ENDPATH**/ ?>