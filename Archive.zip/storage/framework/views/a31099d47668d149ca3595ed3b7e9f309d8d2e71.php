<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="sub-title">Uploads</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="sub-title">Site Logo </h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="photo">Existing Logo</label>
                                    <div class="preview">
                                        <img width="200" height="200"
                                             src="<?php echo e(ViewHelper::getImagePath(@$_folder,@$data['row']->site_logo)); ?>"
                                             class="img-responsive" id="file-ip-1-preview">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="photo_upload">Upload Logo</label> <span class="red">*</span>
                                    <?php echo Form::file('main_logo',[
                                        'class'=> $errors->has('main_logo')?'form-control btn btn-info btn-sm is-invalid':'form-control btn btn-info btn-sm',
                                        'id'=>'photo',
                                        'onchange'=>"showPreview(event);",
                                        'accept'=>'image/png, image/gif, image/jpeg'
                                     ]); ?>

                                    <?php $__errorArgs = ['main_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block invalid-feedback">
                                        <strong> <?php echo e($message); ?> </strong>
                                </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="sub-title">Site Favicon</h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="photo">Existing Favicon</label>
                                    <div class="preview">
                                        <img width="200" height="200"
                                             src="<?php echo e(ViewHelper::getImagePath(@$_folder,@$data['row']->site_favicon)); ?>"
                                             class="img-responsive" id="favicon-preview">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="photo_upload">Upload Company Logo</label>
                                    <?php echo Form::file('main_favicon',[
                                        'class'=> $errors->has('main_favicon')?'form-control btn btn-info btn-sm is-invalid':'form-control btn btn-info btn-sm',
                                        'id'=>'favicon',
                                        'onchange'=>"showFaviconPreview(event);",
                                        'accept'=>'image/png, image/gif, image/jpeg, image/x-icon'
                                     ]); ?>

                                    <?php $__errorArgs = ['main_favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block invalid-feedback">
                                        <strong> <?php echo e($message); ?> </strong>
                                </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="sub-title">Company Logo</h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="photo">Existing Company Logo</label>
                                    <div class="preview">
                                        <img width="200" height="200"
                                             src="<?php echo e(ViewHelper::getImagePath(@$_folder,@$data['row']->company_logo)); ?>"
                                             class="img-responsive" id="company_logo_preview">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="photo_upload">Upload Statistics Map</label>
                                    <?php echo Form::file('main_company_logo',[
                                        'class'=> $errors->has('main_company_logo')?'form-control btn btn-info btn-sm is-invalid':'form-control btn btn-info btn-sm',
                                        'id'=>'company_logo',
                                        'onchange'=>"showCompanyLogoPreview(event);",
                                        'accept'=>'image/png, image/gif, image/jpeg'
                                     ]); ?>

                                    <?php $__errorArgs = ['main_company_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block invalid-feedback">
                                        <strong> <?php echo e($message); ?> </strong>
                                </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="sub-title">StatMap</h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="photo">Existing StatMap</label>
                                    <div class="preview">
                                        <img width="200" height="200"
                                             src="<?php echo e(ViewHelper::getImagePath(@$_folder,@$data['row']->stat_map)); ?>"
                                             class="img-responsive" id="stat_map_preview">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="photo_upload">Upload Favicon</label> <span class="red">*</span>
                                    <?php echo Form::file('main_stat_map',[
                                        'class'=> $errors->has('main_stat_map')?'form-control btn btn-info btn-sm is-invalid':'form-control btn btn-info btn-sm',
                                        'id'=>'stat_map',
                                        'onchange'=>"showStatMapPreview(event);",
                                        'accept'=>'image/png, image/gif, image/jpeg'
                                     ]); ?>

                                    <?php $__errorArgs = ['main_stat_map'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block invalid-feedback">
                                        <strong> <?php echo e($message); ?> </strong>
                                </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="sub-title">Powered By Logo</h5>
                            <div class="row">
                                <div class="col-md-12">
                                    <label for="photo">Existing Company Logo</label>
                                    <div class="preview">
                                        <img width="200" height="200"
                                             src="<?php echo e(ViewHelper::getImagePath(@$_folder,@$data['row']->powered_by_logo)); ?>"
                                             class="img-responsive" id="powered_by_logo_preview">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label for="photo_upload">Upload PoweredByLogo</label> <span class="red">*</span>
                                    <?php echo Form::file('main_powered_by_logo',[
                                        'class'=> $errors->has('main_powered_by_logo')?'form-control btn btn-info btn-sm is-invalid':'form-control btn btn-info btn-sm',
                                        'id'=>'powered_by_logo',
                                        'onchange'=>"showPoweredByLogoPreview(event);",
                                        'accept'=>'image/png, image/gif, image/jpeg'
                                     ]); ?>

                                    <?php $__errorArgs = ['main_powered_by_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block invalid-feedback">
                                        <strong> <?php echo e($message); ?> </strong>
                                </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/upload.blade.php ENDPATH**/ ?>