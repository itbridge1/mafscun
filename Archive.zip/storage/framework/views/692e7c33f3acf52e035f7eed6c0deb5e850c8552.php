<?php $__env->startSection('title', "Gallery"); ?>

<?php $__env->startSection('meta'); ?>
    <?php echo $__env->make('website.common.meta', [
    '_title' => "Gallery",
    '_detail' => "Photo Gallery and Media Albums",
    '_folder' => 'gallery',
    '_photo' => @$_gallery->first()->cover_photo,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Unified Page Heading & Breadcrumb -->
    <?php echo $__env->make('website.common.page-heading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-xl my-4 pb-5">
        <div class="row g-4">
            <?php if(isset($_gallery) && $_gallery->count() > 0): ?>
                <?php $__currentLoopData = $_gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="news-card h-100 d-flex flex-column bg-white rounded-4 border overflow-hidden">
                            <div class="news-img-wrapper" style="position: relative; aspect-ratio: 16/10; overflow: hidden; background: #f8fafc;">
                                <img src="<?php echo e(\App\Facades\ViewHelper::getImagePath('gallery', $album->cover_photo)); ?>"
                                     alt="<?php echo e($album->title ?? 'Gallery Album'); ?>"
                                     class="w-100 h-100" style="object-fit: cover; transition: transform 0.4s ease;">
                                <div class="position-absolute" style="bottom: 12px; right: 12px;">
                                    <span class="badge badge-dark bg-dark px-2 py-1 rounded-pill small" style="opacity: 0.85;">
                                        <i class="fas fa-camera mr-1"></i> Album
                                    </span>
                                </div>
                            </div>
                            <div class="p-4 d-flex flex-column flex-grow-1">
                                <div class="text-muted small mb-2 d-flex align-items-center gap-1">
                                    <i class="far fa-calendar-alt text-success"></i>
                                    <span><?php echo e($album->created_at ? $album->created_at->format('M d, Y') : ''); ?></span>
                                </div>
                                <h5 class="fw-bold mb-2" style="color: var(--public-ink); font-size: 1.15rem;">
                                    <a href="<?php echo e(route('gallery.detail', $album->slug)); ?>" class="text-decoration-none" style="color: inherit;">
                                        <?php echo e($album->title ?? "Gallery Album"); ?>

                                    </a>
                                </h5>
                                <p class="text-muted small flex-grow-1 mb-3" style="line-height: 1.6;">
                                    <?php echo e(\App\Facades\ViewHelper::getStrippedContent($album->description, 130)); ?>

                                </p>
                                <a href="<?php echo e(route('gallery.detail', $album->slug)); ?>" class="btn btn-sm btn-outline-success rounded-pill align-self-start px-3 py-1 font-weight-bold" style="font-size: 0.8rem;">
                                    View Album <i class="fas fa-arrow-right ml-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="events-empty-state text-center p-5 bg-white rounded-4 border">
                        <i class="far fa-images fa-3x mb-3 text-muted"></i>
                        <h4 class="fw-bold text-dark">No Albums Found</h4>
                        <p class="text-muted mb-0">Photo albums will appear here once published.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php if(isset($_gallery) && $_gallery->hasPages()): ?>
            <div class="d-flex justify-content-center mt-4">
                <?php echo $_gallery->links(); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.common.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/gallery/index.blade.php ENDPATH**/ ?>