<div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <h5 class="sub-title">
                Social Links
            </h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Facebook Link</label> <span class="red">*</span>
                        <?php echo Form::text('social[facebook_link]', null,[
                              'class'=> $errors->has('social.facebook_link')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Facebook Link",
                              ]); ?>

                        <?php $__errorArgs = ['social.facebook_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                <strong> <?php echo e($message); ?> </strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Twitter Link</label> <span class="red">*</span>
                        <?php echo Form::text('social[twitter_link]', null,[
                              'class'=> $errors->has('social.twitter_link')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Twitter Link",
                              ]); ?>

                        <?php $__errorArgs = ['social.twitter_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                           <strong> <?php echo e($message); ?> </strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Youtube Link</label>
                        <?php echo Form::text('social[youtube_link]', null,[
                              'class'=> $errors->has('social.youtube_link')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Youtube Link",
                              ]); ?>

                        <?php $__errorArgs = ['social.youtube_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Insta Link</label>
                        <?php echo Form::text('social[insta_link]', null,[
                              'class'=> $errors->has('social.insta_link')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Insta Link",
                              ]); ?>

                        <?php $__errorArgs = ['social.insta_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label> Powered By </label>
                        <?php echo Form::text('powered_by', null,[
                              'class'=> $errors->has('powered_by')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Powered By Text",
                              ]); ?>

                        <?php $__errorArgs = ['powered_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Powered By Link</label>
                        <?php echo Form::text('powered_by_link', null,[
                              'class'=> $errors->has('powered_by_link')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Powered By Text",
                              ]); ?>

                        <?php $__errorArgs = ['powered_by_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>Keywords</label>
                        <?php echo Form::text('keywords', null,[
                              'class'=> $errors->has('keywords')?'form-control is-invalid':'form-control',
                              'placeholder'=>"eg. Keywords",
                              ]); ?>

                        <?php $__errorArgs = ['keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="form-group">
                        <label>SEO Description</label>
                        <?php echo Form::textarea('description', null,[
                              'class'=> $errors->has('description')?'form-control summenote is-invalid':'form-control summenote',
                              'placeholder'=>"eg. Type Here.",
                              ]); ?>

                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block invalid-feedback">
                                    <strong> <?php echo e($message); ?> </strong>
                                </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/social.blade.php ENDPATH**/ ?>