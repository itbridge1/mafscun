<div class="card-body">
    <div class="row">
        <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="home-tab"
                   data-toggle="pill" href="#custom-content-below-home"
                   role="tab" aria-controls="custom-content-below-home"
                   aria-selected="true">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="upload-tab"
                   data-toggle="pill" href="#upload-content"
                   role="tab" aria-controls="upload-content"
                   aria-selected="false">
                    Upload
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="social-tab"
                   data-toggle="pill" href="#social-tab-content"
                   role="tab" aria-controls="social-tab-content"
                   aria-selected="false">
                    Social
                    <?php if($errors->has('social.facebook_link')
                    || $errors->has('social.twitter_link')
                    || $errors->has('social.youtube_link')
                    || $errors->has('powered_by_link')
                    || $errors->has('keywords')
                    || $errors->has('description')
                    || $errors->has('social.insta_link')): ?>
                        <span class="red">*</span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="settings-tab"
                   data-toggle="pill" href="#content-settings"
                   role="tab" aria-controls="content-settings"
                   aria-selected="false">Settings</a>
            </li>
          
        </ul>
        <div class="tab-content" id="custom-content-below-tabContent">
            <div class="tab-pane fade active show" id="custom-content-below-home" role="tabpanel" aria-labelledby="home-tab">
               <?php echo $__env->make($_view_path.'.common.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               <?php echo $__env->make($_view_path.'.common.statistics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="tab-pane fade" id="upload-content" role="tabpanel" aria-labelledby="upload-tab">
                <?php echo $__env->make($_view_path.'.common.upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
             
            <div class="tab-pane fade" id="social-tab-content" role="tabpanel" aria-labelledby="social-tab">
                <?php echo $__env->make($_view_path.'.common.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="tab-pane fade" id="content-settings" role="tabpanel" aria-labelledby="settings-tab">
                <?php echo $__env->make($_view_path.'.common.setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<!-- /.card-body -->
<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
</div>
<?php $__env->startSection('formJs'); ?>
    <?php echo $__env->make($_view_path.'.common.form-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/siteSetting/common/form.blade.php ENDPATH**/ ?>