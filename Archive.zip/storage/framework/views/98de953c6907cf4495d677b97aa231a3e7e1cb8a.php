<?php $__env->startSection('title','Edit '.$_panel); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e("Edit ".$_panel); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e($dashboard_url); ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route($_base_route.'.index')); ?>"><?php echo e($_panel); ?></a></li>
                            <li class="breadcrumb-item"><?php echo e("Edit ".$_panel); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- jquery validation -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title"><?php echo e($_panel); ?> <small>Edit <?php echo e($_panel); ?></small></h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <?php echo Form::model($data['row'], [
                                'url' => route($_base_route.'.update', $data['row']->id),
                                'enctype' => 'multipart/form-data',
                                'id'=>"edit-form"
                            ]); ?>

                            <?php echo method_field('PUT'); ?>
                            <?php echo Form::hidden('id', $data['row']->id); ?>

                                <?php echo $__env->make($_view_path.'.common.form',['button'=>'Update '.$_panel], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo Form::close(); ?>

                        </div>
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                    <!-- right column -->
                    <div class="col-md-6">

                    </div>
                    <!--/.col (right) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->yieldContent('formJs'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.frame', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/resource/edit.blade.php ENDPATH**/ ?>