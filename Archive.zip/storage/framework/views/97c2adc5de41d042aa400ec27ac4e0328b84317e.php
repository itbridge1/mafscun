<?php
    $breadcrumbParents = [];
    if (request()->routeIs('events.show')) {
        $breadcrumbParents[] = ['label' => 'Events', 'url' => route('events.index')];
    } elseif (request()->routeIs('service.detail')) {
        $breadcrumbParents[] = ['label' => 'Services', 'url' => route('service')];
    } elseif (request()->routeIs('news.detail')) {
        $breadcrumbParents[] = ['label' => 'News', 'url' => route('news')];
    } elseif (request()->routeIs('notices.detail')) {
        $breadcrumbParents[] = ['label' => 'Notices', 'url' => route('notices')];
    } elseif (request()->routeIs('about.detail')) {
        $breadcrumbParents[] = ['label' => 'About us', 'url' => route('about')];
    } elseif (request()->routeIs('gallery.detail')) {
        $breadcrumbParents[] = ['label' => 'Gallery', 'url' => route('gallery')];
    } elseif (request()->routeIs('career')) {
        $breadcrumbParents[] = ['label' => 'Notices', 'url' => route('notices')];
    }
?>
<nav class="public-breadcrumb" aria-label="Breadcrumb">
    <ol>
        <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
        <?php $__currentLoopData = $breadcrumbParents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e($parent['url']); ?>"><?php echo e($parent['label']); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li aria-current="page"><?php echo $__env->yieldContent('title', 'Page'); ?></li>
    </ol>
</nav>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/website/common/breadcrumb.blade.php ENDPATH**/ ?>