<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/layout/control-sidebar.blade.php ENDPATH**/ ?>