<footer class="main-footer no-print text-sm">
    
    <div class="float-right d-none d-sm-inline-block">
        <b>
            <a href="<?php echo e($_site_setting->powered_by_link ?? "https://itbridge.com.np"); ?>">
                      <p>© <?php echo e(date('Y')); ?> All Rights Reserved Bagmati Proscun</p>
            </a>
        </b>
    </div>
   
    
</footer>
<?php /**PATH /home/btwneeraj/Desktop/Projects/makwanpur/resources/views/admin/layout/footer.blade.php ENDPATH**/ ?>