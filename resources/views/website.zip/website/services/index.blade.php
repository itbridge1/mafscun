@extends('website.common.layout')

@section('title', $_service->title ?? "Service")
@section('meta')
    @include('website.common.meta', [
    '_title' => $_service->title,
    '_detail' => strip_tags($_service->description),
    '_folder' => 'serviceCategory',
    '_photo' => $_service->photo,
])
@endsection

@section('content')
    <div class="container-fluid bod">
        {{-- <h1>{{ $_service->title ?? "Service" }} </h1> --}}
        <div class="row">
            <div style="padding:5px" class="col-md-12">
                <div class="card">
                    <div class="card-body p-2">
                        <div class="d-flex justify-content-between align-items-center ">
                            <h4>{{ $_service->title }}</h4>
                            <button class="btn btn-link" type="button" 
                                data-toggle="collapse" data-target="#serviceContent" 
                                aria-expanded="false" aria-controls="serviceContent">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                        </div>
                        <div class="collapse" id="serviceContent">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="desc">
                                        {!! $_service->description !!}
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <img src="{{ \App\Facades\ViewHelper::getImagePath('serviceCategory', $_service->photo) }}"
                                         width="100%" alt="{{ $_service->title }}">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @if(isset($_service->children) && $_service->children->count() > 0)
        <div class="row">
            <div class="col-3">
                <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    @foreach($_service->children as $key => $_child)
                        <button class="nav-link {{ $key == 0 ? 'active' : '' }}" id="{{ $_child->slug }}" data-toggle="pill" data-target="#{{ $_child->slug }}-content"
                                type="button" role="tab" aria-controls="home-content" aria-selected="true">
                            {{ $_child->title }}
                        </button>
                    @endforeach
                </div>
            </div>
            <div class="col-9">
                <div class="tab-content" id="v-pills-tabContent">
                    @foreach($_service->children as $key => $_child)
                        <div class="tab-pane fade show {{ $key == 0 ? 'active' : '' }}" id="{{ $_child->slug }}-content" role="tabpanel" aria-labelledby="{{ $_child->slug }}">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3 class="">
                                                {{ $_child->title ?? "Saving" }}
                                            </h3>
                                            <div class="desc">
                                               {!! $_child->description !!}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <img src="{{ \App\Facades\ViewHelper::getImagePath('serviceCategory', $_child->photo) }}"
                                                 width="100%" alt="{{ $_child->title }}">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
        @endif
    </div>

    @include('website.home.affiliation')
@endsection

@section('js')
    <script>
        $('#myTab button').on('click', function (event) {
            event.preventDefault()
            $(this).tab('show')
        })
    </script>
    <script>
        $('.btn-link').on('click', function() {
            $(this).find('i').toggleClass('fa-chevron-down fa-chevron-up');
        });
    </script>
@endsection
