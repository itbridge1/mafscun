@extends('website.common.layout')

@section('title', $_hrmDetail['title'] ?? "Team")

@section('meta')
    @include('website.common.meta', [
    '_title' => $_hrmDetail->title,
    '_keywords' => $_site_setting->keywords,
    '_detail' => strip_tags($_hrmDetail->description),
    '_folder' => 'hrm',
    '_photo' => $_hrmDetail->photo,
])
@endsection

@section('content')
    <!-- about section ends -->
    <div class="container-xl bod">
        <h1>{{ $_hrmDetail['title'] }}</h1>
        <div class="row">
            @if(isset($_hrmDetail->teams) && $_hrmDetail->teams->count() > 0)
                @foreach($_hrmDetail->teams as $key => $team)
                <div class="col-lg-3 col-md-4 col-sm-6 col-12">
                    <div class="card">
                    <img
                        class="circle"
                        src="{{ \App\Facades\ViewHelper::getImagePath('team', $team->photo) }}"
                    />
                    <div class="card-body justify-content-center">
                        <h5 class="card-title title">{{ $team->name ?? "NAME" }}</h5>
                        <h6 class="card-text team-name text-center">{{ $team->designation ?? "Designation" }}</h6>
                        <ul class="social">
                            <li>
                                <a href="mailto:{{  $team->email }}"
                                   class="open_in_new_tab_class" title="{{  $team->email }}"
                                   id="team-social-link">
                                    <i class="fa fa-envelope one"></i>
                                </a>
                            </li>
                            <li>
                                <a tooltip-href="{{  $team->phone }}" wpm-6310-tooltip="yes"
                                   href="tel:{{ $team->phone }}"
                                   class="wpm-6310-tooltip" title="{{  $team->phone }}"
                                   id="team-social-link">
                                    <i class="fa fa-phone one"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                </div>
                @endforeach
            @else
                <div class="col-lg-12 col-md-12 col-sm-12 col-12 text-center">
                    <div class="card">
                        <h5 class="card-title title">
                            No Content To Display
                        </h5>
                    </div>
                </div>
            @endif
        </div>
    </div>

    @include('website.home.affiliation')
@endsection
