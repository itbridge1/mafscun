<div class="container-xl chart">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5 class="text-center stat-header">
                                {{ $_site_setting->statistics_text ?? "Our Member Organization Statistics" }}
                            </h5>
                        </div>
                        <div class="col-md-6">
                            @if(isset($data['_statistics']) && $data['_statistics']->count() > 0)
                                <select id="search-nav-select" class="form-control">
                                    <option selected disabled>--SELECT TO FILTER DISTRICTWISE--</option>
                                    <option value="home" data-toggle="#home">Bagmati Province Report</option>
                                    @foreach($data['_statistics'] as $key => $district)

                                        <option value='{{ \Illuminate\Support\Str::slug($district->d_name) }}'
                                                data-toggle="#{{ \Illuminate\Support\Str::slug($district->d_name) }}">
                                            {{ $district->d_name }} Report
                                        </option>
                                    @endforeach
                                </select>
                            @endif
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-12 col-md-12">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-11">
                                            <img src="{{ ViewHelper::getImagePath('siteSetting', $_site_setting->stat_map) }}" id="chart_map"
                                                 alt="{{ "Bagmati Map" }}" width="100%"
                                                 {{--                 height="450px" --}}
                                                 style="max-height: 500px;">
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-11">
                                            <div class="chart-container">
                                                <canvas id="chart-line" class="chartjs-render-monitor" style="display: block; width: 299px; height: 200px;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @if(isset($data['_statistics']) && $data['_statistics']->count() > 0)
                                    @foreach($data['_statistics'] as $key => $district)
                                        <div class="tab-pane search-nav-tabs fade" id="{{ \Illuminate\Support\Str::slug($district->d_name) }}"
                                             role="tabpanel"
                                             aria-labelledby="{{ \Illuminate\Support\Str::slug($district->d_name) }}-tab">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-6 col-11">
                                                    <img src="{{ ViewHelper::getImagePath('district', $district->d_map) }}"
                                                         id="chart_map{{$key}}"
                                                         alt="{{ $district->d_name }}" width="100%"
                                                         {{--                 height="450px" --}}
                                                         style="max-height: 460px;">
                                                </div>
                                                <div class="col-lg-6 col-md-6 col-11">
                                                    <div class="chart-container">
                                                        <canvas id="chart-line-{{$key}}" class="chartjs-render-monitor"
                                                                style="display: block; width: 299px; height: 200px;">
                                                        </canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                @endif
                            </div>
                        </div>
{{--                        <div class="col-lg-5 col-md-7 col-11 chart-item">--}}
{{--                            <img src="{{ ViewHelper::getImagePath('siteSetting', $_site_setting->stat_map) }}" id="chart_map"--}}
{{--                                 alt="{{ "Bagmati Map" }}" width="100%"--}}
{{--                                 --}}{{--                 height="450px" --}}
{{--                                 style="max-height: 460px;">--}}
{{--                        </div>--}}
{{--                        <div class="col-lg-5 col-md-7 col-11 chart-item">--}}
{{--                            <canvas id="chart-line" width="299" height="200" class="chartjs-render-monitor"--}}
{{--                                    style="display: block; width: 299px; height: 200px;">--}}

{{--                            </canvas>--}}
{{--                        </div>--}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
