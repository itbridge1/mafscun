
<style>
    .container {
  max-width: 100% !important;
  
}
@media (max-width: 765px) {
    .container {

  margin: 0px 15px !important;
} 
}

</style>

<!-- Affiliation section -->
@if(isset($_affiliations) && $_affiliations->count() > 0)
    <div class="container slider " style="border-bottom: 1px solid green">
        <h1 >Affiliations</h1>
        <span class="d-block mx-auto border-bottom border-dark  mt-1" style="width:100px;"></span>
        <div class="row">
            <div class="container">
                <section class="customer-logos slider">
                    @foreach($_affiliations as $key => $affiliation)
                        <div class="slide">
                            <a href="{{ $affiliation->link ?? '#' }}">
                                <img width="100%" style="max-height: 150px; max-width: 150px;" src="{{ \App\Facades\ViewHelper::getImagePath('affiliation', $affiliation->logo) }}">
                            </a>
                        </div>
                    @endforeach
                </section>
            </div>
        </div>
    </div>
@endif
<!-- Affiliation section ends -->
