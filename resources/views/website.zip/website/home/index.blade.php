@extends('website.common.layout')
@section('title', 'Bagmati PROSCUN Home || Home')
@section('meta')
    @include('website.common.meta', [
        '_title' => $_site_setting->title,
        '_keywords' => $_site_setting->keywords,
        '_detail' => strip_tags($_site_setting->description),
        '_folder' => 'siteSetting',
        '_photo' => $_site_setting->site_logo,
    ])
@endsection
<style>
    .contact {
        padding: 20px !important;
        border-radius: 10px !important;
        background-color: rgb(232, 230, 230) !important margin: 20px 0px;
    }

    .emi-calculator .emi-item {
        margin: 20px 5px !important;
        padding: 10px !important;
    }

    .emi-calculator .calculator h3 {
        text-transform: uppercase !important;
        font-weight: 600 !important;
        font-size: 3.5vmin !important;
        color: rgb(82, 199, 82) !important;
    }

    .notice-icon {
        margin-right: -50px;
    }

    .notice {
        padding: 0 !important;
        border-radius: 5px;
        border: 1px solid rgb(255, 255, 255);
        background-color: rgb(255, 255, 255);
        height: max-content
    }

    .about-us-title {
        color: #378d1a;
    }

    .testimonial-item {
        padding: 10px !important;
        border-radius: 5px !important;
        box-shadow: 5px 5px 5px 5px #d7d5d5 !important;
        background: rgb(247, 247, 252) !important;
    }

    .button-notice:hover {
        background: #083434 !important;
        color: black !important;

    }

    .notice .notice-item {
        margin: 0px auto 15px !important;
    }

    .about-us {
        padding: 20px;
        background-color: #f7f4f4 !important;
        box-shadow: 1px 5px 5px 4px #cac4c4 !important;
    }

    .about-us h1 {
        font-size: 4.5vmin;
        margin-left: 0px !important;
        font-weight: 600;
        margin-bottom: 20px;
    }

    .notice .notice-item .notice-content {

        padding: 5px !important;
    }

    .notice .button {

        background-color: rgb(12, 80, 80);
        width: 150px;
        text-align: center;
        line-height: 30px;
        font-weight: 600;
        border-radius: 10px;
        color: #fff;
        text-decoration: none;
        transition: all .5s;

    }

    @media (max-width: 876px) {

        .about-us h1,
        .about-us hr {
            margin-left: 60px !important;
            font-size: 25px !important;
        }

        @media (max-width: 576px) {
            .contact-form {
                margin-top: 20px !important;
            }
        }

    }

    /* Custom hover effect */
    .hover-shadow:hover {
        transform: translateY(-5px);
        box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15) !important;
    }

    .transition-all {
        transition: all 0.3s ease-in-out;
    }

    .caption {
        background: rgba(255, 255, 255, 0.34);
        backdrop-filter: blur(6px);
        -webkit-backdrop-filter: blur(10px);
        padding: 10px;
        border-radius: 5px;
        color: #192b1a;
        font-size: 15px;
    }

    @media (max-width: 576px) {
        .carousel-item img {
            max-height: none !important;
            width: 100% !important;
        }
    }
</style>
@section('content')
    <!-- ========== carousal section========== -->
    @if (isset($data['_sliders']) && $data['_sliders']->count() > 0)
        <div class="container-xl">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <!-- <ol class="carousel-indicators">
                            @foreach ($data['_sliders'] as $key => $_slider)
    <li data-target="#carouselExampleIndicators" data-slide-to="{{ $key }}" class="{{ $key == 0 ? 'active' : '' }}"></li>
    @endforeach
                        </ol> -->
                <div class="carousel-inner">
                    @foreach ($data['_sliders'] as $key => $_slider)
                        <div class="carousel-item d-flex`  {{ $key == 0 ? 'active' : '' }}" data-interval="3000">
                            <img src="{{ \App\Facades\ViewHelper::getImagePath('slider', $_slider->photo) }}"
                                class="d-block w-100 " alt="{{ $_slider->alt_text }}" width="100%"
                                style="max-height: 500px;" />

                            <div class="carousel-caption d-none d-md-block" style="top: 350px">
                                <h5 class="caption">{{ $_slider->caption }}</h5>
                            </div>
                        </div>
                    @endforeach
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    @endif
    <!-- ==========End carousal section========== -->
    <!-- ========== Marquee section========== -->
    @if (isset($data['_latest_news']) && $data['_latest_news']->count() > 0)
        <div class="container-xl">
            <div class="row justify-content-around marquee-row">
                <div class="col-lg-2 text-right col-2"
                    style="padding-top: 9px;
    background-image: url(http://localhost:8090/backend/news1.jpg);
    width: 259px;
    background-position: right;
    background-repeat: no-repeat;">
                    <h3 class="blink" style="color: #fff; padding-left: 20px;">
                        <blink style="animation: blink 1s linear infinite;">
                            Recent News
                        </blink>
                    </h3>
                </div>
                <div class="col-lg-10 col-10" style="padding-top: 10px;">
                    <marquee style="color: #fff;">
                        @foreach ($data['_latest_news'] as $key => $_news)
                            <a href="{{ route('news.detail', $_news->slug) }}" class="marquee-link">
                                {{ $_news->title }}
                            </a>
                            @if (!$loop->last)
                                <span>&emsp; >>>> &emsp; </span>
                            @endif
                        @endforeach
                    </marquee>
                </div>
            </div>
        </div>
    @endif
    <!-- ========== Marquee section========== -->
    <hr />
    @if (isset($data['_aboutUs']))
        <!-- ==========About section========== -->
        <div class="container-fluid about-us">
            <div class="row d-flex justify-content-between">
                <!-- About Us Section -->
                <div class="col-md-7 col-11 about-us-item mx-1">
                    <h1 class="about-us-title">{{ $data['_aboutUs']->title ?? 'About NEFSCUN' }}</h1>
                    <h1 class="border-bottom"></h1>
                    <p style="text-align: justify;">
                        {{ \Illuminate\Support\Str::limit(strip_tags($data['_aboutUs']->description), 1400) }}
                        <a href="{{ route('about.detail', $data['_aboutUs']->slug) }}">Read More</a>
                    </p>
                </div>

                <!-- Notice Section -->
                <div class="col-md-4 col-11  ">
                    <div style="
  
  font-weight: 600;
  " class="d-flex justify-content-center align-items-center ">

                        <h1 style="color: #378d1a;">Notice</h1>
                    </div>
                    <h1 class="border-bottom"></h1>
                    <div class=" notice ">



                        @if (isset($data['_notices']) && $data['_notices']->count() > 0)
                            <div>
                                @foreach ($data['_notices'] as $key => $_notice)
                                    <div class="col-lg-12 col-sm-3 notice-item mb-3">
                                        <div class="notice-content border-bottom pb-3">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="d-flex align-items-center">
                                                    <i class="fa fa-arrow-right"
                                                        style="font-size:10px; color:rgb(8, 149, 18);"></i>
                                                    <h6 class="p-2"><a style="color: #378d1a"
                                                            href="{{ route('notices.detail', $_notice->slug) }}">{{ $_notice->title ?? 'Notice Title' }}</a>
                                                    </h6>
                                                </div>
                                                {{-- <p class="mb-0">{{ \Illuminate\Support\Str::limit(strip_tags($_notice->description), 50) }}</p> --}}
                                                <div class="d-flex flex-column text-right" style="width: 105px;">
                                                    <p class="fs-6 mb-1">{{ $_notice->created_at->diffForHumans() }}</p>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @else
                            <div class="row justify-content-center">
                                <div class="col-lg-10 col-sm-10 notice-item">
                                    <div class="notice-content">
                                        <h5>No Content To Display</h5>
                                    </div>
                                </div>
                            </div>
                        @endif

                        <div class="d-flex justify-content-center mt-4">
                            <div class="d-flex align-items-center">
                                <a href="{{ route('notices') }}" class="text-decoration-none">ALL NOTICES <span
                                        style="font-size:25px;">&#8594;</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif





    <!---------testimonial section--------->
    <div class="container-xl testimonial">
        <h6 class="about-us-title text-center mt-5 pb-2 position-relative" style="font-size: 4.5vmin; font-weight: 600;">
            Messages/Commitment
            <span class="d-block mx-auto border-bottom border-dark  mt-1" style="width:100px;"></span>
        </h6>

        <div class="row justify-content-center">
            @if (isset($data['_commitmentFromCEO']))
                <div class="col-md-5 col-lg-5 testimonial-item ">
                    <div class="section-block d-inline " style="background: ghostwhite;">
                        <div class="testi-meta">
                            <h3 class="mb-3 testimonial-title text-center">
                                {{ $data['_commitmentFromCEO']->title ?? 'Commitment From CEO' }}
                            </h3>
                        </div>
                        <p style="font-size: 16px; text-align: justify; padding: 10px 10px;">
                            <img src="{{ \App\Facades\ViewHelper::getImagePath('aboutUs', $data['_commitmentFromCEO']->photo) }}"
                                alt="300x300" 114="" data-mdb-toggle="animation" data-mdb-animation-start="onHover"
                                data-mdb-animation-reset="true" data-mdb-animation="tada"
                                style="height:150px; width: 150px; float: left; margin-right: 15px; border-radius: 10%;
                         border: 2px solid #fff;">
                            {{ \App\Facades\ViewHelper::getStrippedContent($data['_commitmentFromCEO']->description, 400) }}
                            <a href="{{ route('about.detail', $data['_commitmentFromCEO']->slug) }}"
                                class="inline more-link">
                                Read More
                            </a>
                        </p>
                    </div>
                </div>
            @endif
            @if (isset($data['_chairmanVoice']))
                <div class="col-md-5 col-lg-5 testimonial-item marginbottom-md">
                    <div class="section-block d-inline box-shadow" style="background: ghostwhite;">
                        <div class="testi-meta">
                            <h3 class="mb-3 testimonial-title text-center">
                                {{ $data['_chairmanVoice']->title ?? 'Chairman Voice' }}</h3>
                        </div>
                        <p style="font-size: 16px; text-align: justify; padding: 10px 10px;">
                            <img src="{{ \App\Facades\ViewHelper::getImagePath('aboutUs', $data['_chairmanVoice']->photo) }}"
                                alt="300x300" 114="" data-mdb-toggle="animation"
                                data-mdb-animation-start="onHover" data-mdb-animation-reset="true"
                                data-mdb-animation="tada"
                                style="height:150px; width: 150px; float: left; margin-right: 15px; border-radius: 5%;
                     border: 2px solid #fff;">
                            {{ \App\Facades\ViewHelper::getStrippedContent($data['_chairmanVoice']->description, 400) }}
                            <a href="{{ route('about.detail', $data['_chairmanVoice']->slug) }}"
                                class="inline more-link">
                                Read More
                            </a>
                        </p>
                    </div>
                </div>
            @endif
        </div>
    </div>
    <!---------End testimonial section--------->









    <!--------- Testimonial / Statistics Section --------->


    <!--------- Statistics Section --------->
    <!--------- Statistics Section --------->
    <div class="container-xl testimonial my-5">
        <h6 class="about-us-title text-center mb-4 position-relative fw-bold"
            style="font-size: 4.5vmin; text-transform: uppercase; letter-spacing: 1px;">
            {{ $data['site_setting_title'] ?? 'Statistics' }}
            <span class="d-block mx-auto border-bottom border-dark mt-2" style="width:100px;"></span>
        </h6>

        <div class="row justify-content-center g-4">
            <!-- Card 1 -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card stat-card shadow-lg border-0 rounded-4 text-center h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <div class="icon-circle mb-3" style="background: linear-gradient(135deg, #4caf50, #2e7d32);">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        @forelse($data['site_setting_stat']->whereBetween('rank', [1, 9]) as $statprofile)
                            <div class="d-flex justify-content-between align-items-center w-100">
                                <h5 class="fw-bold text-dark mb-2">{{ $statprofile->name }}</h5>
                                <span>{{ $statprofile->value }}</span>
                            </div>
                        @empty
                        @endforelse

                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card stat-card shadow-lg border-0 rounded-4 text-center h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <div class="icon-circle mb-3" style="background: linear-gradient(135deg, #4caf50, #2e7d32);">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        @forelse($data['site_setting_stat']->whereBetween('rank', [10, 18]) as $statprofile)
                            <div class="d-flex justify-content-between align-items-center w-100">
                                <h5 class="fw-bold text-dark mb-2">{{ $statprofile->name }}</h5>
                                <span>{{ $statprofile->value }}</span>
                            </div>
                        @empty
                        @endforelse

                    </div>
                </div>
            </div>


            <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="card stat-card shadow-lg border-0 rounded-4 text-center h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center p-4">
                        <div class="icon-circle mb-3" style="background: linear-gradient(135deg, #4caf50, #2e7d32);">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        @forelse($data['site_setting_stat']->whereBetween('rank', [19, 27]) as $statprofile)
                            <div class="d-flex justify-content-between align-items-center w-100">
                                <h5 class="fw-bold text-dark mb-2">{{ $statprofile->name }}</h5>
                                <span>{{ $statprofile->value }}</span>
                            </div>
                        @empty
                        @endforelse

                    </div>
                </div>
            </div>



        </div>
    </div>

    <!-- Custom CSS -->
    <style>
        .stat-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background: linear-gradient(135deg, #ffffff, #f9f9f9);
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.15);
        }

        .icon-circle {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 28px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
    </style>

    <!-- Counter Animation JS -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const counters = document.querySelectorAll('.counter');
            const speed = 150; // lower is faster
            const animateCounters = () => {
                counters.forEach(counter => {
                    const updateCount = () => {
                        const target = +counter.getAttribute('data-target');
                        const count = +counter.innerText.replace(/,/g, '');
                        const increment = Math.ceil(target / speed);
                        if (count < target) {
                            counter.innerText = (count + increment).toLocaleString();
                            setTimeout(updateCount, 20);
                        } else {
                            counter.innerText = target.toLocaleString();
                        }
                    };
                    updateCount();
                });
            };

            // Trigger animation when section is visible
            const section = document.querySelector('.testimonial');
            const observer = new IntersectionObserver(entries => {
                if (entries[0].isIntersecting) {
                    animateCounters();
                    observer.disconnect();
                }
            }, {
                threshold: 0.4
            });
            observer.observe(section);
        });
    </script>

    <!---------End testimonial section--------->


    <!---------Chart Section--------->
    @include('website.home.section.chart')
    <!---------End Chart Section--------->
    @if (isset($data['_success_stories']) && $data['_success_stories']->count() > 0)
        <div class="container-xl mt-2">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <h3 class="text-center stat-header">Success Story</h3>
                </div>
                <div class="col-lg-6">
                    <div class="testimonial-box">
                        <div id="_success_stories" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ul class="carousel-indicators">
                                @foreach ($data['_success_stories'] as $key => $_story)
                                    <li data-target="#_success_stories{{ $key }}"
                                        data-slide-to="{{ $key }}" class="{{ $key == 0 ? 'active' : '' }}">
                                    </li>
                                @endforeach
                            </ul>
                            <!-- The slideshow -->
                            <div class="carousel-inner">
                                @foreach ($data['_success_stories'] as $key => $_story)
                                    <div class="carousel-item {{ $key == 0 ? 'active' : '' }}">
                                        <div id="media_image-2" class="widget text-center widget_media_image">
                                            <img width="150" height="150"
                                                src="{{ ViewHelper::getImagePath('successStory', $_story->photo) }}"
                                                class="image success-img" alt="{{ $_story->name }}" loading="lazy"
                                                srcset="{{ ViewHelper::getImagePath('successStory', $_story->photo) }} 300w,
                                                                 {{ ViewHelper::getImagePath('successStory', $_story->photo) }} 150w,
                                                                 {{ ViewHelper::getImagePath('successStory', $_story->photo) }} 612w"
                                                sizes="(max-width: 300px) 100vw, 300px" />
                                        </div>
                                        <div class="text-center">
                                            <p>{!! $_story->description ??
                                                'There are many variations
                                                                                                                                                                            of passages of Lorem Ipsum available, but the majority have suffered
                                                                                                                                                                            alteration in some form, by injected humour, or randomised words which
                                                                                                                                                                            don’t look even slightly believable. If you are going to use a passage
                                                                                                                                                                            of Lorem Ipsum, you need to be sure there isn’t anything embarrassing
                                                                                                                                                                            hidden in the middle of text. All the Lorem Ipsum generators on the
                                                                                                                                                                            Internet tend to repeat predefined chunks as necessary, making this the
                                                                                                                                                                            first true generator on the Internet.' !!}</p>
                                        </div>
                                        <h4 class="testi-name text-center">
                                            {{ $_story->name ?? 'Diya Mirza' }}
                                        </h4>
                                        <div class="text-center">
                                            <ul class="social">
                                                <li>
                                                    <a href="mailto:{{ $_story->email }}" class="open_in_new_tab_class"
                                                        title="{{ $_story->email }}" id="team-social-link">
                                                        <i class="fa fa-envelope one"></i>
                                                        {{ $_story->email }}
                                                    </a>
                                                </li>
                                                <li>
                                                    <a tooltip-href="{{ $_story->phone }}" wpm-6310-tooltip="yes"
                                                        href="tel:{{ $_story->phone }}" class="wpm-6310-tooltip"
                                                        title="{{ $_story->phone }}" id="team-social-link">
                                                        <i class="fa fa-phone one"></i>
                                                        {{ $_story->phone }}
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <br>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
    <div class="container-xl mb-5 mx-2">
        <div class="row d-flex flex-lg-row flex-column  justify-content-center" style="margin-top: 20px;">
            <!-- EMI Calculator -->
            <div class="col-lg-5 col-md-7 col-sm-12 col-12 ">
                <div class="emi-calculator calculator p-3  "
                    style="border-radius: 10px;box-shadow: 5px 7px 6px 1px #cbced0; background: #f2f2f291;">
                    <h3 style="color: #378d1a" class="text-center mb-4 ">EMI Calculator</h3>
                    <form class="form">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="principal">Loan Amount</label>
                                    <input type="number" class="form-control" value="50000" id="principal"
                                        placeholder="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="rate">Interest Rate %</label>
                                    <input type="number" class="form-control" value="10" id="rate"
                                        placeholder="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label for="month">Term (Months)</label>
                            <input type="number" class="form-control" value="5" id="month" placeholder="">
                        </div>
                        <div class="form-group mb-3 text-center">
                            <button type="button" id="calculate" class="btn btn-success btn-sm w-100">CALCULATE
                                EMI</button>
                        </div>
                        <div class="form-group mb-3">
                            <label for="emi">Monthly Payment (EMI)</label>
                            <input type="text" class="form-control" id="emi" placeholder="" readonly>
                        </div>
                        <div class="form-group text-center">
                            <button type="reset" class="btn btn-outline-success btn-sm w-100">RESET</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-lg-7 col-md-10 col-sm-12 col-12 contact-form">
                <div class="contact p-3 " style="box-shadow: 5px 7px 6px 1px #cbced0; background: #f2f2f291;">
                    <h3 class="text-center mb-4">Contact Us</h3>

                    <p>Get in Touch with us!</p>
                    <div style="height: 252px" class="d-flex justify-between">
                        <div class="col-lg-4 ">
                            <ul class="mb-4">
                                <li><i class="fa fa-map-marker" style="font-size:28px;color:rgb(82, 199, 82);"></i>
                                    &nbsp;&nbsp; {{ $_site_setting->location ?? 'New Banepa, Kavre' }}</li>
                                <li><i class="fa fa-mobile" style="font-size:35px;color:rgb(82, 199, 82);"></i>
                                    &nbsp;&nbsp; {{ $_site_setting->phone ?? '+011-665368 ' }}</li>
                                <li><i class="fa fa-envelope" style="font-size:25px;color:rgb(82, 199, 82);"></i>
                                    &nbsp;&nbsp; {{ $_site_setting->email ?? 'info@bagmatiproscun.org.np' }}</li>
                            </ul>
                        </div>
                        <form action="{{ route('contact.store') }}" method="post" class="form col-lg-8"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <input type="text"
                                        class="{{ $errors->has('name') ? 'form-control is-invalid' : 'form-control' }}"
                                        name="name" required value="{{ old('name') }}"
                                        placeholder="Enter your Name">
                                    @error('name')
                                        <span class="help-block invalid-feedback"><strong>{{ $message }}</strong></span>
                                    @enderror
                                </div>
                                <div class="col-md-6 mb-3">
                                    <input type="text"
                                        class="{{ $errors->has('phone') ? 'form-control is-invalid' : 'form-control' }}"
                                        name="phone" required value="{{ old('phone') }}"
                                        placeholder="Enter your Phone Number">
                                    @error('phone')
                                        <span class="help-block invalid-feedback"><strong>{{ $message }}</strong></span>
                                    @enderror
                                </div>
                                <div class="col-md-6 mb-3">
                                    <input type="email"
                                        class="{{ $errors->has('email') ? 'form-control is-invalid' : 'form-control' }}"
                                        name="email" required value="{{ old('email') }}"
                                        placeholder="Enter your Email">
                                    @error('email')
                                        <span class="help-block invalid-feedback"><strong>{{ $message }}</strong></span>
                                    @enderror
                                </div>

                                <div class="col-md-6 mb-3">
                                    <input type="text"
                                        class="{{ $errors->has('subject') ? 'form-control is-invalid' : 'form-control' }}"
                                        name="subject" value="{{ old('subject') }}" placeholder="Enter your Subject">
                                    @error('subject')
                                        <span class="help-block invalid-feedback"><strong>{{ $message }}</strong></span>
                                    @enderror
                                </div>

                                <div class="col-12 mb-3">
                                    <textarea class="{{ $errors->has('message') ? 'form-control is-invalid' : 'form-control' }}" name="message"
                                        rows="3" placeholder="Enter your Message">{{ old('message') }}</textarea>
                                    @error('message')
                                        <span class="help-block invalid-feedback"><strong>{{ $message }}</strong></span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group text-end">
                                <button type="submit" class="btn btn-outline-success">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-lg my-5 mx-5">
        <!-- Section Title -->
        <div class="text-center mb-4">
            <h2 style="color: #378d1a" class="fw-bold d-inline-block  pb-1">Services</h2>
            <span class="d-block mx-auto border-bottom border-dark  mt-1" style="width:100px;"></span>


        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-4 g-4">
            @forelse($data['_serviceslist'] as $service)
                <div class="col">
                    <a href="{{ route('service.detail', $service->slug) }}" class="text-decoration-none text-dark">
                        <div class="card shadow-sm border-0 rounded-3 h-100 hover-shadow transition-all">
                            <div class="card-img-top position-relative">
                                <img src="{{ \App\Facades\ViewHelper::getImagePath('serviceCategory', $service->photo) }}"
                                    alt="{{ $service->title }}" class="img-fluid rounded-top" width="100%">
                            </div>
                            <div class="card-body text-center">
                                <h5 class="card-title fw-bold mb-2" style="color: #378d1a;">{{ $service->title }}</h5>
                            </div>
                        </div>
                    </a>
                </div>
            @empty
                <div class="col-12">
                    <p class="text-center">No services available at the moment.</p>
                </div>
            @endforelse
        </div>

    </div>
    @include('website.home.affiliation')

    @forelse($data['_popup'] as $_pop)
        <div class="modal show fade" id="exampleModalCenter{{ $_pop->id }}" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <h5 class="modal-title text-center" id="noticeModalTitle{{ $_pop->id }}">
                            {{ $_pop->title }}
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span style="color: red; font-size: 25px; " aria-hidden="true">&times;</span>
                            </button>
                        </h5>
                        <img style="display: block; margin-left: auto; margin-right: auto;" width="100%"
                            src="{{ \App\Facades\ViewHelper::getImagePath('notice', $_pop->photo) }}"
                            alt="{{ $_pop->title }}">
                        <div class="text-center">
                            <a href="{{ route('notices.detail', $_pop->slug) }}">View Detail...</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @empty
        <!-- No popups available -->
    @endforelse

@endsection

@section('js')
    <script>
        $(function() {
            calculateEMI();

            function setValue(element, value) {
                $(element).val(value);
            }

            function getValue(element) {
                return parseFloat($(element).val());
            }

            function calculateEMI() {
                let principal = getValue('#principal');
                let rate = getValue('#rate') / 1200;
                let month = getValue('#month');
                let r = 1 + rate;
                let p = principal * rate;
                let t = Math.pow(r, month);
                let u = p * t;
                let d = t - 1;

                let emi = (u / d).toFixed(2);

                setValue('#emi', emi)
            }
            $('body').on('click', '#calculate', function() {
                calculateEMI();
            })

            $('#search-nav-select').on('change', function(e) {
                var thisVal = $(this).val()
                $('.tab-pane').removeClass('active show');
                $('#' + thisVal).addClass("active show");
            })
        })
    </script>
    @if (isset($data['_popup']))
        <script>
            $(document).ready(function() {
                // Loop through each modal box
                @forelse($data['_popup'] as $_pop)
                    // Show the modal box
                    $('#exampleModalCenter{{ $_pop->id }}').modal('show');
                @empty
                    // No popups available
                @endforelse
            });
        </script>
    @endif
    <script src="{{ asset('website/assets/chart.js') }}"></script>
    <script>
        @php
            $labels = $data['_statistics']->pluck('d_name')->toArray();
            $datas = $data['_statistics']->pluck('associated')->toArray();
            $totals = $data['_statistics']->pluck('total')->toArray();
            $colors = $data['_statistics']->pluck('color')->toArray();
        @endphp
        var xValues = @phpecho json_encode(
                                        array_map(
                                            function ($label, $data) {
                                                return $label . '(' . $data . ')';
                                            },
                                            $labels,
                                            $datas,
                                        ),
                        ); @endphp ?> ? > ;
        var yValues = @php echo json_encode($datas); @endphp;
        var totalValues = @php echo json_encode($totals); @endphp;
        var barColors = @php echo json_encode($colors); @endphp;

        callChart("chart-line", xValues, yValues, totalValues, barColors, "Bagmati Province Organization Report")

        function callChart(chartId, xValues, yValues, totalValues, barColors, title) {
            const ctx = document.getElementById(chartId);
            new Chart(ctx, {
                type: "pie",
                data: {
                    labels: xValues,
                    datasets: [{
                            label: 'Total',
                            backgroundColor: barColors,
                            data: totalValues
                        },
                        {
                            label: 'Associated',
                            backgroundColor: barColors,
                            data: yValues
                        },
                    ]
                },
                options: {
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: title
                        },
                    }
                },
            });
        }

        @foreach ($data['_statistics'] as $key => $statistics)
            @php
                $labels = $statistics->pluck('municipality_name')->toArray();
                $datas = $statistics->pluck('associated')->toArray();
                $totals = $statistics->pluck('total')->toArray();
                $colors = $statistics->pluck('color')->toArray();
            @endphp
            var xValues = @phpecho json_encode(
                                                    array_map(
                                                        function ($label, $data) {
                                                            return $label . '(' . $data . ')';
                                                        },
                                                        $labels,
                                                        $datas,
                                                    ),
                                    ); @endphp ?> ? > ;
            var yValues = @php echo json_encode($datas); @endphp;
            var totalValues = @php echo json_encode($totals); @endphp;
            var barColors = @php echo json_encode($colors); @endphp;
            var title = '{{ $statistics->d_name }} Organization Report';
            callChart("chart-line-{{ $key }}", xValues, yValues, totalValues, barColors, title);
        @endforeach
    </script>
@endsection
