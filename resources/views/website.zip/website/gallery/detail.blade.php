@extends('website.common.layout')
@section('title', $_gallery->title ?? "Gallery Title")
@section('css')
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css"
    />
@endsection

@section('meta')
    @include('website.common.meta', [
    '_title' => $_gallery->title,
    '_detail' => strip_tags($_gallery->description),
    '_folder' => 'gallery',
    '_photo' => $_gallery->cover_photo,
])
@endsection

@section('content')
    <!-- ==========Breadcrumb section========== -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="pl-40">
                <h4  class="breadcumb-title">
                    Gallery
                </h4>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="/">
                    <i class="fa fa-home" style="font-size:25px;color: rgb(82, 199, 82);"></i>
                </a>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="{{ route('gallery') }}">
                    Gallery
                </a>
            </li>
            <li class="breadcrumb-item active mr-3" style="font-size:15px;" aria-current="page">{{"Gallery Detail" }}</li>
        </ol>
    </nav>
    <!-- ==========End Breadcrumb section========== -->

    <!-- ==========Detail section========== -->
    <div class="container-fluid contact">
        <div class="container contact-us">
            <div class="contact-heading">
                <h3>{{ $_gallery->title ?? 'फाेटाे ग्यालेरी'  }}</h3>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="flex flex-wrap gap-5 justify-center max-w-5xl mx-auto px-6">
                        <a data-fancybox="gallery" href="{{ ViewHelper::getImagePath('gallery',$_gallery->cover_photo)}}">
                            <img class="rounded" src="{{ ViewHelper::getImagePath('gallery','200_150_'.$_gallery->cover_photo)}}" />
                        </a>
                        @if(isset($_gallery->images) && $_gallery->images->count() > 0)
                            @foreach($_gallery->images as $_image)
                                <a data-fancybox="gallery" href="{{ ViewHelper::getImagePath('gallery',$_image->photo)}}">
                                    <img class="rounded" src="{{ ViewHelper::getImagePath('gallery','200_150_'.$_image->photo)}}" />
                                </a>
                            @endforeach
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ==========End Detail section========== -->

    <!-- ==========Extra section========== -->
@if(isset($_other_news) && $_other_news->count() > 0)
    <div class="container-fluid extra">
        <h2>
            <div class="extra-title">
                Other News
            </div>
        </h2>
        <div class="row extra-row">
            @foreach($_other_news as $key => $other_news)
                <div class="col-lg-3 col-md-4 col-6 extra-col">
                    <div class="extra-item">
                        @if($other_news->parent)
                            <p class="hover-type">
                                <a href="">{{ $other_news->parent->title ?? "Category" }}</a>
                            </p>
                        @endif
                        <div class="extra-img d-flex align-items-center">
                            <img src="{{ \App\Facades\ViewHelper::getImagePath('news', $other_news->photo) }}"
                                 alt="{{ $other_news->title }}" width="100%" height="">
                        </div>
                        <a href="{{ route('news.detail', $other_news->slug) }}">
                            <h5 class="text-center">{{ $other_news->title ?? "News Title" }}</h5>
                        </a>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endif

    <!-- ==========End Extra section========== -->
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
@endsection
