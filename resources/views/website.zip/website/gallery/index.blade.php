@extends('website.common.layout')

@section('title', "Gallery")

@section('meta')
    @include('website.common.meta', [
    '_title' => "Gallery",
    '_detail' => "Gallery List of Proscun",
    '_folder' => 'gallery',
    '_photo' => @$_gallery->first()->cover_photo,
])
@endsection

@section('content')
    <!-- -------News Section--------- -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="pl-40">
                <h4  class="breadcumb-title">Gallery</h4>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="/">
                    <i class="fa fa-home" aria-hidden="true" style="font-size:28px;color: rgb(82, 199, 82);"></i>
                </a>
            </li>
            <li class="breadcrumb-item active mr-5" aria-current="page">Gallery</li>
        </ol>
    </nav>

    <div class="container-xl m-3">
        <h1 class="heading">Gallery List</h1>

        <div class="row">
            @if(isset($_gallery) && $_gallery->count() > 0)
                @foreach($_gallery as $key => $album)
                    <div class="col-lg-4 col-md-6 col-sm-6 cards-a">
                        <div class="cards">
                            <div class="image-holder">
                                <img src="{{ \App\Facades\ViewHelper::getImagePath('gallery', $album->cover_photo) }}"
                                     alt="{{ $album->title ?? "Gallery Photo" }}" class="img-custom">
                            </div>
                            <div class="contain">
                                <h4><b>{{ $album->title ?? "Gallery Title" }}</b></h4>
                                <h6><i class="fa fa-calendar"></i>{{ $album->created_at->format('M d, Y') }}</h6>
                                <p> {{ \App\Facades\ViewHelper::getStrippedContent($album->description,180) }}</p>
                                <a href="{{ route('gallery.detail',$album->slug) }}">View all..</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="text-center">
                                No Content To Display
                            </h6>
                        </div>
                    </div>
                </div>
            @endif
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="justify-content-center mt-5">
                    {!! $_gallery->links() !!}
                </div>
            </div>
        </div>
    </div>
    <!-- -------News Section Ends--------- -->
@endsection
