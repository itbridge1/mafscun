@extends('website.common.layout')
@section('title', "Notices")
@section('meta')
    @include('website.common.meta', [
    '_title' => "Notices",
    '_detail' => "Notice List Of Bagmati Proscun",
    '_folder' => 'notice',
    '_photo' => $_notices->first()->photo?? "",
])
@endsection
@section('content')
    <div class="container">

    </div>
        <!-- ==========Breadcrumb section========== -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="pl-40">
                    <h4  class="breadcumb-title">
                        Notices
                    </h4>
                </li>
                <li class="breadcrumb-item ml-auto ">
                    <a href="/">
                        <i class="fa fa-home" style="font-size:25px; color: rgb(82, 199, 82);"></i>
                    </a>
                </li>
                <li class="breadcrumb-item active mr-3" style="font-size:15px;" aria-current="page">{{"Notices List" }}</li>
            </ol>
        </nav>
        <!-- ==========End Breadcrumb section========== -->
        <!---------notic section--------->
        <div class="container-xl notice">
            <div class="icon">
                <i class="fa fa-newspaper-o" style="color:rgb(255, 255, 255); font-size:35px;"></i> <h1>Notices</h1>
            </div>
            @if(isset($_notices) && $_notices->count() > 0)
                <div class="row justify-content-center">
                    @foreach($_notices as $key => $_notice)
                        <div class="col-lg-3 col-sm-5 notice-item">
                            <div class="notice-content text-center">
                                <h5>{{ $_notice->title ?? "Notice Title" }}</h5>
                                <p> Start Date : {{ $_notice->start_date }} End Date: {{ $_notice->end_date }}</p>
                                <p> {{ $_notice->created_at->diffForHumans() }} </p>
                                <p>{{ \Illuminate\Support\Str::limit(strip_tags($_notice->description),50) }}</p>
                                <p>
                                    <a href="{{ route('notices.detail', $_notice->slug) }}">Read more</a>
                                </p>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="row justify-content-center">
                    <div class="col-lg-10 col-sm-10 notice-item">
                        <div class="notice-content">
                            <h5 class="text-center">No Content To Display</h5>
                        </div>
                    </div>
                </div>
            @endif

            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="justify-content-center">
                        {!! $_notices->links() !!}
                    </div>
                </div>
            </div>
        </div>
        <!---------End notic section--------->
@endsection
