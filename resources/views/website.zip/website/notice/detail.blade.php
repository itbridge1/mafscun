@extends('website.common.layout')
@section('title', $_notice->title ??  $head ?? "Notices" )

@section('meta')
    @include('website.common.meta', [
    '_title' => $_notice->title,
    '_detail' => strip_tags($_notice->description),
    '_folder' => 'notice',
    '_photo' => $_notice->photo,
])
@endsection

@section('content')
    <!-- ==========Breadcrumb section========== -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="pl-40">
                <h4  class="breadcumb-title">
                    {{ $head ?? "Notices" }}
                </h4>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="/">
                    <i class="fa fa-home" style="font-size:25px;color: rgb(82, 199, 82);"></i>
                </a>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="{{ $head ? route('career') : route('notices') }}">
                    {{ $head ?? "Notices" }}
                </a>
            </li>
            <li class="breadcrumb-item active mr-3" style="font-size:15px;" aria-current="page">{{ $_notice->title ?? "News Title" }}</li>
        </ol>
    </nav>
    <!-- ==========End Breadcrumb section========== -->

    <!-- ==========Detail section========== -->
    <div class="container-xl details">
        <div class="row justify-content-around">
            <div class="col-xl-9 col-lg-8 details-item details-left">
                <div class="details-head">
                    <h2 class="heading">{{ $_notice->title ?? "News Title" }}</h2>
                    <ul class="information">
                        <li><span class="badge badge-success">From :{{ $_notice->start_date ?? "" }}</span></li>
                        <li><span class="badge badge-danger">To: {{ $_notice->end_date ?? "" }}</span></li>
                        <li>
                            <i class="fa fa-clock-o"></i>
                            {{ $_notice->created_at->diffForHumans() }},
                            {{ $_notice->created_at->format('M d, Y') }}
                        </li>
                    </ul>
                    <img src="{{ \App\Facades\ViewHelper::getImagePath('notice', $_notice->photo) }}"
                         width="100%"
                         alt="{{ $_notice->title }}"
                         class="news-detail-img mt-4">
                    <br>
                    <div class="desc mt-2">
                        {!! $_notice->description !!}
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-12 col-11 details-item details-right">
                <h5><span>Latest Notices</span></h5>
                <div class="row trending">
                    @if(isset($_other_notices) && $_other_notices->count() > 0)
                        @foreach($_other_notices as $key => $latest_notice)
                        <div class="col-lg-12 col-sm-6 col-11">
                            <div class="row justify-content-around right-topic trending-item">
                            <div class="col-4">
                                <div class="nmbr">
                                    <h3>{{ ++$key }}.</h3>
                                </div>
                            </div>
                            <div class="col-8">
                                <h4>{{ $latest_notice->title }} </h4>
                                <p>{{ $latest_notice->start_date ?? "Bagmati Proscun" }} - {{ $latest_notice->end_date ?? "Banepa" }}
                                    <a href="{{ route('notices.detail', $latest_notice->slug) }}">
                                       View Now...
                                    </a>
                                </p>
                            </div>
                        </div>
                        </div>
                        @endforeach
                    @else
                        <div class="col-lg-12 col-sm-6 col-11">
                            <div class="row justify-content-around right-topic trending-item">
                                <div class="col-12">
                                    <p>No Content To Display</p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- ==========End Detail section========== -->
@endsection
