@extends('website.common.layout')
@section('title', "Resources")
@section('meta')
    @include('website.common.meta', [
    '_title' => "Resources",
    '_detail' => "Resources List Of Bagmati Proscun",
    '_folder' => 'resource',
    '_photo' => $_resources->first()->photo?? "",
])
@endsection
@section('content')
        <!-- ==========Breadcrumb section========== -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="pl-40">
                    <h4  class="breadcumb-title">
                        Resources
                    </h4>
                </li>
                <li class="breadcrumb-item ml-auto ">
                    <a href="/">
                        <i class="fa fa-home" style="font-size:25px; color: rgb(82, 199, 82);"></i>
                    </a>
                </li>
                <li class="breadcrumb-item active mr-3" style="font-size:15px;" aria-current="page">{{"Resources List" }}</li>
            </ol>
        </nav>
        <!-- ==========End Breadcrumb section========== -->
    <!-- ============= Download Section ============== -->
    <div class="container-xl download m-3">
        <h2>Resources</h2>
        <div class="row">
            <div class="col-12 download-search">
                <p>Filter: </p>
                <form action="{{ route('resources') }}" method="get" class="form" enctype="multipart/form-data">
                    <div class="form-group">
                        {!! Form::select('filter_resource_type',$_resourceTypes, null, [
                            'class' => 'form-control',
                            'placeholder' => '--SELECT RESOURCE TYPE--'
                        ]) !!}
                    </div>
                    <div class="form-group">
                        {!! Form::text('filter_title', null, [
                            'class' => 'form-control',
                            'placeholder' => 'Type title keywords..'
                        ]) !!}
                    </div>
                    <div class="form-group">
                        <button type="submit" class="form-control searchbtn btn btn-outline-success">Search</button>
                    </div>
                </form>
            </div>
            <div class="col-12 download-list">
                @if(isset($_resources) && $_resources->count() > 0)
                    @foreach($_resources as $key => $resource)
                        <div class="row justify-content-between align-items-center d-list">
                    <div class="col-md-1 col-2 date">
                        <div class="div date-box">
                            <h3>{{ $resource->created_at->format('d') }}</h3><br>
                            <p>{{ $resource->created_at->format('M, Y') }}</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-6 title">
                        <h3>{{ $resource->title ?? "title" }}</h3><br>
                        {!! $resource->description !!}
                    </div>
                    <div class="col-md-3 col-3 action">
                        @if($resource->type == "file")
                            <a href="{{ \App\Facades\ViewHelper::getImagePath('resource', $resource->file) }}"
                               download="{{ \Illuminate\Support\Str::slug($resource->title)."-".$resource->file }}"
                               class="btn-sm btn-primary">
                                <i class="fa fa-download " style="font-size: 18px;" aria-hidden="true"></i>
                                &nbsp;<span class="mobile-hide">Download</span>
                            </a>
                        @endif
                            <a target="_blank"
                               href="{{ $resource->type == "file" ?\App\Facades\ViewHelper::getImagePath('resource', $resource->file) : $resource->file }}"
                               class="btn-sm btn-success">
                                <i class="fa fa-eye " style="font-size: 18px;" aria-hidden="true"></i>
                                &nbsp; <span class="mobile-hide">
                                    View
                                </span>
                            </a>

{{--                        <form class="form" method="post" enctype="multipart/form-data">--}}
{{--                            <div class="form-group">--}}
{{--                            </div>--}}
{{--                        </form>--}}
                    </div>
                </div>
                    @endforeach
                @endif
            </div>
        </div>
    </div>
    <br>
    <!-- =============End Download Section ============== -->

    <!-- =============Pagination Section ============== -->
    <div class="row">
        <div class="col-md-12">
            <div class="justify-content-center">
                {!! $_resources->links() !!}
            </div>
        </div>
    </div>
    <br>
    <!-- =============End Pagination Section ============== -->
@endsection
