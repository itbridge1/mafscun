@extends('website.common.layout')

@section('title', $_aboutUs['title'] ?? "About")

@section('meta')
    @include('website.common.meta', [
    '_title' => $_aboutUs->title,
    '_keywords' => $_site_setting->keywords,
    '_detail' => strip_tags($_aboutUs->description),
    '_folder' => 'aboutUs',
    '_photo' => $_aboutUs->photo,
])
@endsection

@section('content')
    <!-- about section -->

    <section class="container-md innner-blog m-5 shadow-sm">
        {{-- <h6 style="color: #029e49" >About Us</h6> --}}
        <h4 style="color: #029e49">{{ $_aboutUs['title'] }}</h4>
        <hr>
        <div>
            <blockquote style="text-align: justify; border-left: 5px solid #029e49; padding-left: 15px;">
                <span class="innner-blog-image" style="float: right; margin-left: 15px; margin-bottom: 10px;">
                    <img src="{{ \App\Facades\ViewHelper::getImagePath('aboutUs', $_aboutUs->photo) }}" 
                         alt="{{ $_aboutUs['title'] }}" 
                         width="300px"/>
                </span>
                <p>{!! $_aboutUs['description'] !!}</p>
            </blockquote>
        </div>
    </section>
    <!-- about section ends -->

@endsection

