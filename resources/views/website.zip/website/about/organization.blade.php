@extends('website.common.layout')

@section('title', "Organization List" ?? "About")

@section('meta')
    @include('website.common.meta', [
    '_title' => "Organization List",
    '_keywords' => 'members in proscun, bagmati proscun, organizations, sahakari in bagmati proscun',
    '_detail' => "Bagmati Proscun Member Organization List",
    '_folder' => 'siteSetting',
    '_photo' => $_site_setting->company_logo,
])
@endsection

@section('content')
    <!-- about section -->
    <div class="container-fluid about">
        <h3 class="mt-4">Organization List</h3>
        <div class="row">
            <div class="col-lg-11 col-md-11 col-11">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">District</th>
                                    <th scope="col">Municipality</th>
                                    <th scope="col">President</th>
                                    <th scope="col">Manager</th>
                                    <th scope="col">ContactNo</th>
                                    <th scope="col">PAN No</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if($_organizations && $_organizations->count() > 0)
                                    @foreach($_organizations as $key => $organization)
                                        <tr>
                                            <th scope="row"> {{ ++$key }}</th>
                                            <td> {{ $organization->name }}</td>
                                            <td>{{ $organization->district->name ?? "District" }}</td>
                                            <td>{{ $organization->municipality->name ?? "Municipality" }}</td>
                                            <td> {{ $organization->bod_chief }} </td>
                                            <td> {{ $organization->manager }} </td>
                                            <td> {{ $organization->contact_no }} </td>
                                            <td> {{ $organization->pan_no }} </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td class="text-center" colspan="8">Organization list is being updating soon..</td>
                                    </tr>
                                @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
{{--            <div class="col-lg-7 col-md-6 col-11">--}}
{{--                <h1> {{ $_organization['name'] }} </h1>--}}
{{--                <hr>--}}
{{--                <p>--}}
{{--                    {!! $_organization['description'] !!}--}}
{{--                </p>--}}
{{--            </div>--}}
{{--            <div class="col-lg-4 col-md-5 col-11 image">--}}
{{--                <img src="{{ \App\Facades\ViewHelper::getImagePath('aboutUs', $_organization->photo) }}"--}}
{{--                     alt="{{ $_organization['title'] }}"--}}
{{--                     width="100%">--}}
{{--            </div>--}}
        </div>
    </div>
    <!-- about section ends -->

@endsection
