@extends('website.common.layout')
@section('title', $_aboutUs['title'] ?? "About")

@section('meta')
    @include('website.common.meta', [
    '_title' => $_aboutUs->title ?? "About Us",
    '_keywords' => $_site_setting->keywords,
    '_detail' => strip_tags($_aboutUs->description) ?? "Bagmati Proscun",
    '_folder' => 'aboutUs',
    '_photo' => $_aboutUs->photo ?? '',
])
@endsection
@section('content')
    <!-- about section -->
    <div class="container-xl mt-4 about">
        <h3>About Us</h3>
        <div class="row">
            <div class="col-lg-7 col-md-6 col-11">
                <h1> {{ $_aboutUs['title'] ?? "About Us" }} </h1>
                <hr>
                <p>
                    {!! $_aboutUs['description'] ?? "" !!}
                </p>
            </div>
            <div class="col-lg-4 col-md-5 col-11 image">
                <img src="{{ \App\Facades\ViewHelper::getImagePath('aboutUs', $_aboutUs->photo??'') }}"
                     alt="{{ $_aboutUs['title'] ?? 'AboutUs Photo' }}"
                     width="100%">
            </div>
        </div>
    </div>
    <!-- about section ends -->

    <!-- about section -->
    <div class="container-xl mt-4 about">
        <h3>Other About Us</h3>
        <div class="row">
            @if(isset($_aboutUsList) && $_aboutUsList->count() > 0)
                @foreach($_aboutUsList as $key => $aboutUsL)
                    <div class="col-lg-4 col-md-6 col-sm-6 cards-a">
                        <div class="cards">
                            <div class="image-holder">
                                <img src="{{ \App\Facades\ViewHelper::getImagePath('aboutUs', $aboutUsL->photo) }}"
                                     alt="{{ $aboutUsL->title ?? "News Photo" }}"
                                     class="img-custom">
                            </div>
                            <div class="contain">
                                <h4><b>{{ $aboutUsL->title ?? "News Title" }}</b></h4>
                                <h6><i class="fa fa-calendar"></i>{{ $aboutUsL->created_at->format('M d, Y') }}</h6>
                                <p> {{ \App\Facades\ViewHelper::getStrippedContent($aboutUsL->description,200) }}</p>
                                <a href="{{ route('about.detail',$aboutUsL->slug) }}">Read More..</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="text-center">
                                No Content To Display
                            </h6>
                        </div>
                    </div>
                </div>
            @endif
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="justify-content-center mt-5">
                    @if(isset($_aboutUsList) && $_aboutUsList->count() > 0)
                    {!! $_aboutUsList->links() !!}
                        @endif
                </div>
            </div>
        </div>
    </div>
    <!-- about section ends -->
@endsection
