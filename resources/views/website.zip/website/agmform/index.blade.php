@extends('website.common.layout')
@section('title', "AGM Nomination Form")
@section('content')
    <!-- about section -->
    <div class="container-xl mt-4 about">
        <h3>AGM Nomination Form</h3>
      
        <form id="agm-form" action="{{ route('agmform.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name"> Representative Name In English /प्रतिनिधीको नाम * </label>
                    <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}" required>
                    @error('name')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="nepali_name">प्रतिनिधीको नाम देवनागरीमा*</label>
                    <input type="text" class="form-control" id="nepali_name" name="nepali_name" value="{{ old('nepali_name') }}"  >
                    @error('nepali_name')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="gender">Gender/लिंग *</label>
                    <select class="form-control" id="gender" name="gender" required>
                        <option value="male" {{ old('gender') == 'male' ? 'selected' : '' }}>Male</option>
                        <option value="female" {{ old('gender') == 'female' ? 'selected' : '' }}>Female</option>
                        <option value="other" {{ old('gender') == 'other' ? 'selected' : '' }}>Other</option>
                    </select>
                    @error('gender')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="saccos_union">Name of Saccos/Union/संघसंस्थाको नाम * </label>
                    <input type="text" class="form-control" id="saccos_union" name="saccos_union" value="{{ old('saccos_union') }}" required>
                    @error('saccos_union')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="post">Post in Representative SACCOS/DU / प्रतिनिधित्व गरेको संघसस्थामा बहाल रहेको पद* </label>
                    <select class="form-control" id="post" name="post" required>
                        @foreach(config('helper.post') as $post)
                            <option value="{{ $post }}" {{ old('post') == $post ? 'selected' : '' }}>{{ $post }}</option>
                        @endforeach
                    </select>
                    @error('post')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>


                <div class="form-group col-md-4">
                    <label for="email">Email Address / इमेल ठेगाना *</label>
                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" required>
                    @error('email')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group col-md-4">
                    <label for="district">District/जिल्ला *</label>
                    <select class="form-control" id="district" name="district_id" required onchange="fetchMunicipalities(this.value)">
                        @forelse($data['districts'] as $district)
                            <option value="{{ $district->id }}" {{ old('district') == $district->id || 29 == $district->id ? 'selected' : '' }}>{{ $district->name}}</option>
                        @empty
                        @endforelse
                    </select>
                    @error('district_id')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="address">Local level(Municipality) / स्थानीय तह(पालिकाको नाम) *</label>
                    <select class="form-control" id="address" name="municipality_id" required>
                        <option value="">Select Municipality</option>
                    </select>
                    @error('address')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="ward_no">Ward No /वडा नं. *</label>
                    <input type="number" class="form-control" id="ward_no" name="ward_no" value="{{ old('ward_no') }}" required>
                    @error('ward_no')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="membership_no">Membership No in Bagmati Proscun /बागमती प्रोस्कूनमा सदस्यता नं.*</label>
                    <input type="text" class="form-control" id="membership_no" name="membership_no" value="{{ old('membership_no') }}" required>
                    @error('membership_no')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="mobile_no">Mobile No of Representative /प्रतिनिधीको सम्पर्क नं.*</label>
                    <input type="text" class="form-control" id="mobile_no" name="mobile_no" value="{{ old('mobile_no') }}" required minlength="8" maxlength="15">
                    @error('mobile_no')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="nomination_form">Upload Duty Filled & Approved Representative Nomination Form / मनोनयन फारम अपलोड गर्नुहोस्* (Maximum file size: 5MB)</label>
                    <input type="file" class="form-control-file" id="nomination_form" name="main_nomination_form" required>
                    @error('nomination_form')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="photo">Upload Passport Size Photo for ID Card/परिचयपत्रको लागि पासपोर्ट साईजको फोटो अपलोड गर्नुहोस् । * (Maximum file size: 5MB)</label>
                    <input type="file" class="form-control-file" id="photo" name="main_photo" required onchange="previewImage(event)">
                    <img id="photo-preview" src="#" alt="Passport Size Photo" style="display:none; margin-top:10px; max-width:100px;" required>
                    @error('photo')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    
    @section('js')
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        @if(\Illuminate\Support\Facades\Session::has('success_message'))
            Swal.fire({
                icon: 'success',
                title: 'Thank you',
                text: '{{ \Illuminate\Support\Facades\Session::get('success_message') }}',
                footer: '<a href="{{ route('index') }}"><i class="fa fa-home"></i> Go to Home Page</a>'
            })
        @endif
        @if(\Illuminate\Support\Facades\Session::has('error_message'))
            Swal.fire({
                icon: 'error',
                title: 'Sorry',
                text: '{{ \Illuminate\Support\Facades\Session::get('error_message') }}',
                footer: '<a href="{{ route('index') }}"><i class="fa fa-home"></i> Go to Home Page</a>'
            })
        @endif
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        function previewImage(event) {

            var reader = new FileReader();
            reader.onload = function(){
                var output = document.getElementById('photo-preview');
                output.src = reader.result;
                output.style.display = 'block';
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
    <script>
        $(document).ready(function() {
            districtId =   $('#district').val();
            fetchMunicipalities(districtId);
        });
        function fetchMunicipalities(districtId) {
            $.ajax({
                url:"{{ route('municipalities.get') }}",
                method: 'GET',
                data:{
                    _token: '{{ csrf_token() }}',
                    districtId: districtId,
                },
                success: function(data) {
                    let municipalitySelect = $('#address');
                    municipalitySelect.html('<option value="">Select Municipality</option>');
                    data.forEach(function(municipality) {
                        let option = $('<option></option>').val(municipality.id).text(municipality.name);
                        municipalitySelect.append(option);
                    });
                },
                error: function(error) {
                    console.error('Error fetching municipalities:', error);
                }
            });
        }
    </script>
@endsection

 @endsection
