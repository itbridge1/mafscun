@extends('website.common.layout')
@section('title', 'Contact Us')
@section('meta')
    @include('website.common.meta', [
    '_title' => "Contact Us",
    '_detail' => "$_site_setting->location ?? 'New Banepa, kavre' . $_site_setting->phone ?? '+011-665368' . $_site_setting->email ?? 'info@bagmatiproscun.org.np'",
    '_folder' => 'siteSetting',
    '_photo' => $_site_setting->site_logo,
])
@endsection
<style>
    /* ...existing code... */

.container-xl.contact {
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.contact-col h3 {
    color: #52c752;
    margin-bottom: 15px;
}

.contact-col p {
    font-size: 16px;
    color: #555;
}

.contact-col ul {
    list-style: none;
    padding: 0;
}

.contact-col ul li {
    margin-bottom: 10px;
    font-size: 16px;
    color: #333;
}

.contact-col ul li i {
    color: #52c752;
}

.form-col p {
    font-size: 18px;
    font-weight: bold;
    color: #333;
    margin-bottom: 15px;
}

.form-group {
    margin-bottom: 15px;
}

.form-control {
    border-radius: 5px;
    border: 1px solid #ddd;
    padding: 10px;
    font-size: 14px;
}

.form-control.is-invalid {
    border-color: #e3342f;
}

.help-block.invalid-feedback {
    color: #e3342f;
}

.submitbtn {
    background-color: #52c752;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.submitbtn:hover {
    background-color: #45a645;
    color: white !important;        
}

@media (max-width: 768px) {
    .contact-col, .form-col {
        margin-bottom: 20px;
    }
}
</style>
@section('content')
    <!-- -------News Section--------- -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="pl-40">
                <h4  class="breadcumb-title">Contact Us</h4>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="/">
                    <i class="fa fa-home" aria-hidden="true" style="font-size:28px;color: rgb(82, 199, 82);"></i>
                </a>
            </li>
            <li class="breadcrumb-item active mr-5" aria-current="page">Contact Us</li>
        </ol>
    </nav>
    <!-- ==========contact form section========== -->
    <div class="container-xl contact">
        <div class="row justify-content-between">
            <div class="col-lg-4 col-md-5 contact-col">

                <p>Get in Touch with us!</p>
                <ul>
                    <li><i class="fa fa-map-marker"></i> &nbsp;&nbsp; {{ $_site_setting->location ?? "New Banepa, kavre" }}</li>
                    <li><i class="fa fa-mobile"></i> &nbsp;&nbsp; {{ $_site_setting->phone ?? "+011-665368 " }}</li>
                    <li><i class="fa fa-envelope"></i> &nbsp;&nbsp; {{ $_site_setting->email ?? "info@bagmatiproscun.org.np" }}</li>
                </ul>
            </div>
            <div class="col-xl-8 col-md-7 contact-col form-col">
                <p>Leave A Message</p>
                <form action="{{ route('contact.store') }}" method="post" class="form" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="{{$errors->has('name')?'form-control is-invalid':'form-control'}}" name="name"
                                       id="name" aria-describedby="nameId" required
                                       value="{{ old('name') }}"
                                       placeholder="Enter your Name">
                                @error('name')
                                <span class="help-block invalid-feedback">
                                    <strong> {{ $message }} </strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="{{$errors->has('phone')?'form-control is-invalid':'form-control'}}" name="phone"
                                       id="phone" aria-describedby="phoneId"
                                       value="{{ old('phone') }}"
                                       placeholder="Enter your Phone Number" max="15" required>
                                @error('phone')
                                <span class="help-block invalid-feedback">
                                        <strong> {{ $message }} </strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" class="{{$errors->has('email')?'form-control is-invalid':'form-control'}}"
                                       name="email" id="" aria-describedby="emailHelpId"
                                       required
                                       value="{{ old('email') }}"
                                       placeholder="Enter your email">
                                @error('email')
                                <span class="help-block invalid-feedback">
                                        <strong> {{ $message }} </strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="{{$errors->has('subject')?'form-control is-invalid':'form-control'}}" name="subject"
                                       id="subject" aria-describedby="emailHelpId"
                                       value="{{ old('subject') }}"
                                       placeholder="Enter your Subject">
                                @error('subject')
                                <span class="help-block invalid-feedback">
                                        <strong> {{ $message }} </strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="hidden" class="{{$errors->has('captcha')?'form-control is-invalid':'form-control'}}" name="captcha"
                                       value="{{ old('captcha') }}"
                                       placeholder="Do not Fill this captcha">
                                <textarea class="{{$errors->has('message')?'form-control is-invalid':'form-control'}}"
                                          name="message" id="message"
                                          rows="2" 
                                          > {{ old('message') }}
                                </textarea>
                                @error('message')
                                <span class="help-block invalid-feedback">
                                        <strong> {{ $message }} </strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex justify-content-end">
                        <button type="submit" class="submitbtn btn btn-outline-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- ==========End contact form section========== -->

    @include('website.home.affiliation')
@endsection
@section('js')
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        @if(\Illuminate\Support\Facades\Session::has('success_message'))
            Swal.fire({
                icon: 'success',
                title: 'Thank you',
                text: '{{ \Illuminate\Support\Facades\Session::get('success_message') }}',
                footer: '<a href="{{ route('index') }}"><i class="fa fa-home"></i> Go to Home Page</a>'
            })
        @endif
        @if(\Illuminate\Support\Facades\Session::has('error_message'))
            Swal.fire({
                icon: 'error',
                title: 'Sorry',
                text: '{{ \Illuminate\Support\Facades\Session::get('error_message') }}',
                footer: '<a href="{{ route('index') }}"><i class="fa fa-home"></i> Go to Home Page</a>'
            })
        @endif
    </script>
@endsection
