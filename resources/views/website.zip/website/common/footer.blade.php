<style>
    footer h3 {
  font-size: 18px !important;
  color: rgb(82, 199, 82) !important;
  font-weight: bolder !important;
  padding-top: 10px;
  
}
</style>

<footer>
    <!-- ==========footer top section========== -->
    <div class="container-xl footer-top">
        <div class="row justify-content-between">
            <div class="col-md-3 col-6 footer-item">
                {!! $_site_setting->footer_text !!}
                <!-- <div class="row justify-content-start">
                    <div class="col-2">
                        <a href="{{ $_site_setting['social']['facebook_link'] }}">
                            <i class="fa fa-facebook-square" style="font-size:28px;color:rgb(47, 62, 197);"></i>
                        </a>
                    </div>
                    <div class="col-2">
                        <a href="{{ $_site_setting['social']['youtube_link'] }}">
                            <i class="fa fa-youtube-square" style="font-size:28px;color:rgb(212, 14, 14);"></i>
                        </a>
                    </div>
                </div> -->
            </div>
            <div class="col-md-3 col-6 footer-item">
                @if(isset($_footer1))
                    <h3>{{ $_footer1->title ?? "QUICK LINKS" }}</h3>
                    @if(isset($_footer1->children) && $_footer1->children->count() > 0)
                        <ul>
                            @foreach($_footer1->children as $key => $menu)
                                <li><a href="{{ $menu->menu_url }}">{{ $menu->title }}</a></li>
                            @endforeach
                        </ul>
                    @endif
                @endif
            </div>
            <div class="col-md-4 col-6 footer-item">
                {{-- @if (count($_site_setting->statistics) > 0)
                    <div class="col-lg-12 mt-8 mt-lg-0">
                             <h3 class="text-center">Statistics</h3>
                            @forelse ($_site_setting->statistics as $stat_data)
                                <div class="stats-row d-flex justify-content-between">
                                    <span class="stats-name" >{{ $stat_data->name . ':' ?? null }}</span>
                                    <span class="stats-value" style="text-align: right;">{{ $stat_data->value }}</span>
                                </div>
                            @empty
                                <p>No statistics available.</p>
                            @endforelse
                        </div>
                 @endif --}}
            </div>
        </div>
    </div>
         
           
           
    </div>
    <!-- ==========end footer top section========== -->

    <!-- ==========footer bottom section========== -->
    <div class="row footer-info justify-content-between">
        <div class="col-md-8 col-12">
            <p>© {{ $_site_setting->copyright_text ?? "All Rights Reserved ". date('Y')." IT BRIDGE NEPAL" }}</p>
        </div>
        <div class="col-md-4 col-12 d-flex justify-content-end">
            <p>Powered by <a target="_blank" href="{{ $_site_setting->powered_by_link ?? "null" }}"><span style="Font-weight:bold;color: rgb(82, 199, 82);">{{ $_site_setting->powered_by ?? "ITB" }}</span></a></p>
        </div>
    </div>
    <!-- ==========end footer bottom section========== -->
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" type="text/javascript" ></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
@yield('js')
<script type="text/javascript">
    $(document).ready(function(){
        $('.customer-logos').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000,
            arrows: false,
            dots: false,
            pauseOnHover: true,
            responsive: [{
                breakpoint: 768,
                settings: {
                    slidesToShow: 3
                }
            }, {
                breakpoint: 520,
                settings: {
                    slidesToShow: 2
                }
            }]
        });
    });
</script>
</body>
</html>
