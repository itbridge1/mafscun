<style>
    header {
        background-color: #029e49;
        height: 50px !important;
    }

   
</style>
<header>
    <div class="row justify-content-between">
        <div class=" col-xl-6 col-lg-8 col-md-9 col-12 banner">
            <ul>
                <li><i class="fa fa-envelope banner-icon"></i> &nbsp; {{ $_site_setting->email ?? "info@bagmatiproscun.org.np" }}</li>
                <li><i class="fa fa-phone banner-icon"></i> &nbsp;{{ $_site_setting->phone ?? "011-665368" }}</li>
                <li><i class="fa fa-map-marker banner-icon"></i>&nbsp; {{ $_site_setting->location ?? "Banepa -7" }}</li>
            </ul>
           
        </div>
        
        <div class="col-xl-2 col-lg-3 col-md-3 col-12 social-banner banner">
            
            <ul>
                <li>
                    <a target="_blank" href="{{ $_site_setting->social['facebook_link'] ?? "#" }}">
                        <i class="fa fa-facebook banner-icon"></i>
                    </a>
                </li>
                <li>
                    <a target="_blank" href="{{ $_site_setting->social['twitter_link'] ?? "#" }}">
                        <i class="fa fa-twitter banner-icon"></i>
                    </a>
                </li>
                <li>
                    <a target="_blank" href="{{ $_site_setting->social['insta_link'] ?? "#" }}">
                        <i class="fa fa-instagram banner-icon"></i>
                    </a>
                </li>
                <li>
                    <a target="_blank" href="{{ $_site_setting->social['youtube_link'] ?? "#" }}">
                        <i class="fa fa-youtube banner-icon"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</header>
