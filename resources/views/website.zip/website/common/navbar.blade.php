<style>
    nav{
        box-shadow: 2px 2px 5px 0px rgba(0,0,0,0.1);
    }
</style>
<nav class="navbar navbar-expand-xl sticky-top">
    <a class="navbar-brand" href="/">
        <img
            src="{{ \App\Facades\ViewHelper::getImagePath('siteSetting', $_site_setting->site_logo) ?? asset('website/img/logo.png') }}"
            alt="{{ $_site_setting->title }}" height="80px" width="270px">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon">
              <i class="fa fa-navicon" style="color:rgb(82, 199, 82); font-size:28px;"></i>
            </span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
            <li class="nav-item">
                <a class="nav-link {{ request()->is('/')? "active-nav":"" }}" href="/">
                    Home
                    <span class="sr-only">
                        (current)
                    </span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link {{ request()->is('about-us*')|| request()->is('organization')? "active-nav":"" }} dropdown-toggle" href="{{ route('about') }}" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    About Us
                </a>
                @if(isset($_aboutMenu))
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @foreach($_aboutMenu as $key => $menu)
                            <li>
                                <a class="dropdown-item {{ request()->is('about-us/'.$menu->slug)? "active-nav":"" }}"
                                   href="{{ route('about.detail', $menu->slug) }}">
                                    {{ $menu->title ?? "Menu".++$key }}
                                </a>
                            </li>
                        @endforeach
                        <li>
                            <a class="dropdown-item {{ request()->is('organization')? "active-nav":"" }}"
                               href="{{ route('organization') }}">
                                {{ "Organization" }}
                            </a>
                        </li>
                    </ul>
                @endif
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link {{ request()->is('hrm*')? "active-nav":"" }} dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    HRM
                </a>
                @if(isset($_hrm))
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown" >
                        @foreach($_hrm as $key => $menuHrm)
                            <li>
                                <a class="dropdown-item {{ request()->is('hrm/'.$menuHrm->slug)? "active-nav":"" }}" href="{{ route('hrm.detail', $menuHrm->slug) }}">
                                    {{ $menuHrm->title }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link {{ request()->is('service*')? "active-nav":"" }} dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Services
                </a>
                @if(isset($_service_categories))
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown" >
                        @foreach($_service_categories as $key => $category)
                            <li>
                                <a class="dropdown-item {{ request()->is('service/'.$category->slug)? "active-nav":"" }}" href="{{ route('service.detail', $category->slug) }}">
                                    {{ $category->title }}
                                </a>
                                @if(isset($category->children) && $category->children->count() > 0)
                                    <ul class="dropdown-menu dropdown-submenu" >
                                        @foreach($category->children as $key => $cat)
                                            <li>
                                                <a style="font-size: 13px" class="dropdown-item {{ request()->is('service/'.$cat->slug)? "active-nav":"" }}" href="{{ route('service.detail', $cat->slug) }}">
                                                    {{ $cat->title }}
                                                </a>
                                            </li>
                                        @endforeach
                                    </ul>
                                @endif
                            </li>
                        @endforeach
                    </ul>
                @endif
            </li>
            <li class="nav-item">
                <a class="nav-link {{ request()->is('news*')? "active-nav":"" }}" href="{{ route('news') }}">
                    News and Events
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link {{ request()->is('notices*')? "active-nav":"" }} dropdown-toggle"
                   href="{{ route('notices') }}" id="navbarDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Notices
                </a>
				<ul class="dropdown-menu" aria-labelledby="navbarDropdown" >
                    <li>
                        <a class="dropdown-item {{ request()->is('notices*')? "active-nav":"" }}" href="{{ route('notices') }}">
                            Notices
                        </a>
                    </li>
					<li>
                        <a class="dropdown-item {{ request()->is('career*')? "active-nav":"" }}" href="{{ route('career') }}">
                            Career
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link  {{ request()->is('resources*')? "active-nav":"" }}" href="{{ route('resources') }}">Resources</a>
            </li>
            <li class="nav-item">
                <a class="nav-link  {{ request()->is('gallery*')? "active-nav":"" }}" href="{{ route('gallery') }}">Gallery</a>
            </li>
            <li class="nav-item">
                <a class="nav-link  {{ request()->is('contact*')? "active-nav":"" }}" href="{{ route('contact') }}">Contact Us</a>
            </li>

            {{-- <a href="{{ route('agmform') }}" class="btn btn-primary">Nomination Form</a> --}}
             <a href="https://elibrary.bagmatiproscun.org.np/" class="btn btn-primary">E-Library</a>
           

        </ul>
    </div>
</nav>
