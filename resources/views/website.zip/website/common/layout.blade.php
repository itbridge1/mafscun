<!doctype html>
<html lang="en">
@include('website.common.head')
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<div class="container-xl">
    <!-- ==========HEADER section========== -->
    @include('website.common.header')
    <!-- ==========End HEADER section========== -->
</div>
<!-- ==========navbar section========== -->
@include('website.common.navbar')
<!-- ==========End nabar section========== -->

{{--<div class="main-content">--}}
    @yield('content')
{{--</div>--}}
@include('website.common.footer')
