@extends('website.common.layout')
@section('title', "Sugestion Form")
@section('content')
    <!-- about section -->
    <div class="container-xl mt-4 about">
        <h3>सुझाव फारम</h3>
    
        <form id="suggestion-form" action="{{ route('suggestionform.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="name">सुझाव दिने व्यक्तिको नाम (स्वेच्छिक):</label>
                    <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}">
                    @error('name')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
    
                <div class="form-group col-md-4">
                    <label for="organization">संघ / संस्थाको नाम (स्वेच्छिक):</label>
                    <input type="text" class="form-control" id="organization" name="organization" value="{{ old('organization') }}">
                    @error('organization')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
    
                <div class="form-group col-md-4">
                    <label for="address">ठेगाना (स्वेच्छिक):</label>
                    <input type="text" class="form-control" id="address" name="address" value="{{ old('address') }}">
                    @error('address')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
    
                <div class="form-group col-md-12">
                    <label for="management-feedback">साधारण सभाको व्यवस्थापन कस्तो लाग्यो? *</label>
                    <div>
                        <label><input type="radio" name="management_feedback" value="very_good"  > उत्तम</label>
                        <label><input type="radio" name="management_feedback" value="good"  > राम्रो</label>
                        <label><input type="radio" name="management_feedback" value="satisfactory"  > सन्तोषजनक</label>
                        <label><input type="radio" name="management_feedback" value="needs_improvement"  > सुधार गर्नुर्पर्छ</label>
                    </div>
                    @error('management_feedback')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group col-md-12">
                    <label for="notification">साधारण सभाको सूचना समयमै प्राप्त भएको थियो वा थिएन ? *</label>
                    <div>
                        <label><input type="radio" name="notification" value="yes"  > थियो</label>
                        <label><input type="radio" name="notification" value="no"  > थिएन</label>
                    </div>
                    @error('notification')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
    
                <div class="form-group col-md-12">
                    <label for="report-feedback">४औं वार्षिक साधारण सभाको प्रतिवेदन माथि केही भन्नु छ?</label>
                    <textarea class="form-control" id="report-feedback" name="report_feedback" rows="4">{{ old('report_feedback') }}</textarea>
                    @error('report_feedback')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
    
                <div class="form-group col-md-12">
                    <label for="policy-feedback">संघको वार्षिक नीति तथा कार्यक्रममा तपाईंको सुझाव केहि छ?</label>
                    <textarea class="form-control" id="policy-feedback" name="policy_feedback" rows="4">{{ old('policy_feedback') }}</textarea>
                    @error('policy_feedback')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
    
                <div class="form-group col-md-12">
                    <label for="other-suggestions">संघलाई तपाईंको अन्य कुनै सुझाव छ?</label>
                    <textarea class="form-control" id="other-suggestions" name="other_suggestions" rows="4">{{ old('other_suggestions') }}</textarea>
                    @error('other_suggestions')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
            </div>
    
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    
    
    @section('js')
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        @if(\Illuminate\Support\Facades\Session::has('success_message'))
            Swal.fire({
                icon: 'success',
                title: 'Thank you',
                text: '{{ \Illuminate\Support\Facades\Session::get('success_message') }}',
                footer: '<a href="{{ route('index') }}"><i class="fa fa-home"></i> Go to Home Page</a>'
            })
        @endif
        @if(\Illuminate\Support\Facades\Session::has('error_message'))
            Swal.fire({
                icon: 'error',
                title: 'Sorry',
                text: '{{ \Illuminate\Support\Facades\Session::get('error_message') }}',
                footer: '<a href="{{ route('index') }}"><i class="fa fa-home"></i> Go to Home Page</a>'
            })
        @endif
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

   
@endsection

 @endsection
