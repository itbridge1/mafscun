<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AGM Verification</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            margin-top: 50px;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
            transition: 0.3s;
            border-radius: 10px;
        }
        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
        }
        .container {
            padding: 2px 16px;
        }
    </style>
</head>
<body>
    <div class="d-flex justify-content-center">
        <div class="card" style="width: 50%;">
            <div class="container">
                @if ($data['success'] == 0)
                    <div class="alert alert-danger mt-3" role="alert">
                        <i class="fas fa-exclamation-circle"></i> In our system, your data is not found.
                    </div>
                @elseif ($data['success'] == 1)
                    <div class="alert alert-success mt-3" role="alert">
                        <i class="fas fa-check-circle"></i> Data found successfully.
                    </div>
                    <p><strong>Name:</strong> {{ $agm['name']??null }}</p>
                    <p><strong>Email:</strong> {{ $agm['email']??null }}</p>
                    <p><strong>Phone Number:</strong> {{ $agm['mobile_no']??null }}</p>
                @endif
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>