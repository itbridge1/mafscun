@extends('website.common.layout')
@section('title', $_news->title ?? "News Title")

@section('meta')
    @include('website.common.meta', [
    '_title' => $_news->title,
    '_detail' => strip_tags($_news->description),
    '_folder' => 'news',
    '_photo' => $_news->photo,
])
@endsection

@section('content')
    <!-- ==========Breadcrumb section========== -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="pl-40">
                <h4  class="breadcumb-title">
                    News And Events
                </h4>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="/">
                    <i class="fa fa-home" style="font-size:25px;color: rgb(82, 199, 82);"></i>
                </a>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="{{ route('news') }}">
                    News
                </a>
            </li>
            <li class="breadcrumb-item active mr-3" style="font-size:15px;" aria-current="page">{{"News Detail" }}</li>
        </ol>
    </nav>
    <!-- ==========End Breadcrumb section========== -->

    <!-- ==========Detail section========== -->
    <div class="container-xl details">
        <div class="row justify-content-around">
            <div class="col-xl-9 col-lg-8 details-item details-left">
                <div class="details-head">
                    <h2 class="heading">{{ $_news->title ?? "News Title" }}</h2>
                    <ul class="information">
                        <li><span class="badge badge-primary">{{ $_news->parent->title ?? "" }}</span></li>
                        <li> <i class="fa fa-user"></i> {{ $_news->author ?? "Bagmati PROSCUN" }}</li>
                        <li>
                            <i class="fa fa-clock-o"></i>
                            {{ $_news->created_at->diffForHumans() }},
                            {{ $_news->created_at->format('M d, Y') }}
                        </li>
                        <li>
                            <i class="fa fa-location-arrow"></i>
                            {{ $_news->location }}
                        </li>
                    </ul>
					<!-- ShareThis BEGIN -->
						<div class="sharethis-inline-share-buttons"></div>
					<!-- ShareThis END -->
                    <img src="{{ \App\Facades\ViewHelper::getImagePath('news', $_news->photo) }}"
                         width="100%"
                         alt="{{ $_news->title }}"
                         class="news-detail-img mt-4">
                    <br>
                    <div class="desc mt-2">
                        {!! $_news->description !!}
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-4 col-sm-12 col-11 details-item details-right">
                <h5><span>Trending News</span></h5>
                <div class="row trending">
                    @if(isset($_trending_news) && $_trending_news->count() > 0)
                        @foreach($_trending_news as $key => $trend)
                        <div class="col-lg-12 col-sm-6 col-11">
                            <div class="row justify-content-around right-topic trending-item">
                            <div class="col-4">
                                <div class="nmbr">
                                    <h3>{{ ++$key }}.</h3>
                                </div>
                            </div>
                            <div class="col-8">
                                <h4>{{ $trend->title }} </h4>
                                <p>{{ $trend->author ?? "Bagmati Proscun" }} - {{ $trend->location ?? "Banepa" }}
                                    <a href="{{ route('news.detail', $trend->slug) }}">
                                       View Now...
                                    </a>
                                </p>
                            </div>
                        </div>
                        </div>
                        @endforeach
                    @else
                        <div class="col-lg-12 col-sm-6 col-11">
                            <div class="row justify-content-around right-topic trending-item">
                                <div class="col-12">
                                    <p>No Content To Display</p>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <!-- ==========End Detail section========== -->

    <!-- ==========Extra section========== -->
@if(isset($_other_news) && $_other_news->count() > 0)
    <div class="container-xl extra">
        <h2>
            <div class="extra-title">
                Other News
            </div>
        </h2>
        <div class="row extra-row">
            @foreach($_other_news as $key => $other_news)
                <div class="col-lg-3 col-md-4 col-6 extra-col">
                    <div class="extra-item">
                        @if($other_news->parent)
                            <p class="hover-type">
                                <a href="">{{ $other_news->parent->title ?? "Category" }}</a>
                            </p>
                        @endif
                        <div class="extra-img d-flex align-items-center">
                            <img src="{{ \App\Facades\ViewHelper::getImagePath('news', $other_news->photo) }}"
                                 alt="{{ $other_news->title }}" width="100%" height="">
                        </div>
                        <a href="{{ route('news.detail', $other_news->slug) }}">
                            <h5 class="text-center">{{ $other_news->title ?? "News Title" }}</h5>
                        </a>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endif

    <!-- ==========End Extra section========== -->
@endsection
