@extends('website.common.layout')

@section('title', "News And Events")

@section('meta')
    @include('website.common.meta', [
    '_title' => "News And Events",
    '_detail' => "News And Events",
    '_folder' => 'news',
    '_photo' => @$_news->first()->photo,
])
@endsection

@section('content')
    <!-- -------News Section--------- -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="pl-40">
                <h4  class="breadcumb-title">News And Events</h4>
            </li>
            <li class="breadcrumb-item ml-auto ">
                <a href="/">
                    <i class="fa fa-home" aria-hidden="true" style="font-size:28px;color: rgb(82, 199, 82);"></i>
                </a>
            </li>
            <li class="breadcrumb-item active mr-5" aria-current="page">News And Events</li>
        </ol>
    </nav>
    <div class="container">
        <h1 class="heading">News And Events</h1>

        <div class="row">
            @if(isset($_news) && $_news->count() > 0)
                @foreach($_news as $key => $news)
                    <div class="col-lg-4 col-md-6 col-sm-6 cards-a">
                        <div class="cards">
                            <div class="image-holder">
                                <img src="{{ \App\Facades\ViewHelper::getImagePath('news', $news->photo) }}"
                                     alt="{{ $news->title ?? "News Photo" }}"
                                     class="img-custom">
                            </div>
                            <div class="contain">
                                <h4><b>{{ $news->title ?? "News Title" }}</b></h4>
                                <h6><i class="fa fa-calendar"></i>{{ $news->created_at->format('M d, Y') }}</h6>
                                <p> {{ \App\Facades\ViewHelper::getStrippedContent($news->description,180) }}</p>
                                <a href="{{ route('news.detail',$news->slug) }}">Read More..</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="text-center">
                                No Content To Display
                            </h6>
                        </div>
                    </div>
                </div>
            @endif
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="justify-content-center mt-5">
                    {!! $_news->links() !!}
                </div>
            </div>
        </div>
    </div>
    <!-- -------News Section Ends--------- -->
@endsection
